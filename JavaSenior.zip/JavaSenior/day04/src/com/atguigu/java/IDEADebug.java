package com.atguigu.java;

import org.junit.Test;

/**
 * @author zyp
 * @create 2023-02-03 19:31
 */
public class IDEADebug {
    @Test
    public void testStringBuffer(){
        String str=null;
        StringBuffer sb=new StringBuffer();
        sb.append(str);
        System.out.println(sb.length());//4
        System.out.println(sb);//“null”

        StringBuffer sb1 = new StringBuffer(str);//抛异常  NullPointerException
        System.out.println(sb1);//“NullPointerException”异常

    }
}
