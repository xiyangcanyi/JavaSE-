package com.atguigu.java;

/**
 *
 *例子：创建三个窗口卖票，总票数为100张----三个对象，三个线程
 * 说明：在继承了Thread类创建多线程方式中，慎用this充当同步监视器。考虑使用当前类
 * 存在线程安全问题：待解决。
 *
 *
 * @author zyp
 * @create 2023-01-28 0:08
 */

class Window2 extends Thread{
    private static int ticket=100;
    private static Object obj=new Object();//加了static保证了唯一性obj
    @Override
    public void run() {
        while (true) {
//            synchronized (this){//错误的每次new对象，this不唯一，this有t1、t2、t3
           // synchronized (obj){//由于new了三个对象，所以object不唯一，导致重票
            synchronized (Window2.class){//Class class=Window2.class类也是对象，Window2只会加载一次
            if (ticket>0){
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(getName()+":卖票，票号为："+ticket);
                ticket--;
            }else {
                break;
            }
        }
        }
    }
}

class WindowTest2 {
   public static void main(String[] args) {
       Window2 t1 = new Window2();
       Window2 t2 = new Window2();
       Window2 t3 = new Window2();
       t1.setName("窗口1");
       t2.setName("窗口2");
       t3.setName("窗口3");
       t1.start();
       t2.start();
       t3.start();



   }
}

