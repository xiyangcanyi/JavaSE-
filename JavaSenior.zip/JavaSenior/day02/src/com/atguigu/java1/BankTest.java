package com.atguigu.java1;

/**
 * 使用同步机制将单例模式中的懒汉式改写为线程安全的
 *
 * 面试题：饿汉式vs懒汉式
 *
 * @author zyp
 * @create 2023-01-30 12:32
 */
public class BankTest {
    public static void main(String[] args) {

    }
}
class Bank {
    private Bank(){}
    private static Bank instance=null;
//    public static synchronized Bank getInstance(){
    public static  Bank getInstance() {
//        方式一：效率稍差
//        synchronized (Bank.class) {
//            if (instance == null) {
//                instance = new Bank();
//            }
//            return instance;
//        }
//        方式二：效率高
        if (instance==null){
            synchronized (Bank.class){
                if (instance==null){
                    instance=new Bank();
                }

            }
        }
        return instance;

    }

}