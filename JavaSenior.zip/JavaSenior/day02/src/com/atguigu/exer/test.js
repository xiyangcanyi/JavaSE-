let input=[["a","b","cd"],["de"],["e","f"]]
function cheek(arr1,arr2){
    let newArr=[]
    let l1=arr1.length
    let l2=arr2.length
    for (var i = 0; i <l1; i++) {
        for (var j = 0; j < l2; j++) {
            newArr.push(arr1[i]+arr2[j])
        }

    }
    return newArr
}
function out(newa1,newa2=[]){
    for (var i = 0; i < newa1.length-1; i++) {
        newa2=cheek(newa1[i],newa1[i+1])
        newa1[i+1]=newa2
    }
    return newa2
}

console.log(out(input));