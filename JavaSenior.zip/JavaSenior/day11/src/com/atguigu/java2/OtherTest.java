package com.atguigu.java2;

import com.atguigu.java1.Person;
import org.junit.Test;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 *
 *
 * @author zyp
 * @create 2023-02-14 10:31
 */
public class OtherTest {
    /*
    获取构造器
     */
    @Test
    public void test1(){
        Class clazz = Person.class;
//        getConstructors():获取当前运行时类中声明的public的构造器
        Constructor[] constructors = clazz.getDeclaredConstructors();
        for(Constructor c:constructors){
            System.out.println(c);
        }
        System.out.println();
//        getDeclareedConstructors（）：获取当前运行时类中声明的所有的构造器
        Constructor[] declaredConstructors = clazz.getDeclaredConstructors();
        for (Constructor constructor : declaredConstructors) {
            System.out.println(constructor);
        }
    }

    /*
    获取运行时类的父类
     */
    @Test
    public void test2(){
        Class<Person> clazz = Person.class;
//      获取当前运行时类的父类
        Class<? super Person> superclass1 = clazz.getSuperclass();
        System.out.println(superclass1);

//      获取当前运行时类的带泛型的父类
        Type superclass = clazz.getGenericSuperclass();

        System.out.println(superclass);
    }

    /*
    获取当前运行时类的带泛型的父类的泛型
     */
    @Test
    public void test3(){
        Class<Person> clazz = Person.class;


//      获取当前运行时类的带泛型的父类
        Type superclass = clazz.getGenericSuperclass();
        ParameterizedType parameterizedType=(ParameterizedType)superclass;
        Type[] typeArguments = parameterizedType.getActualTypeArguments();
        for (Type typeArgument : typeArguments) {
//            System.out.println(typeArgument.getTypeName());
//            System.out.println(((Class)(typeArgument)).getName());
        }
        System.out.println(((Class)(typeArguments[0])).getName());
//        System.out.println(superclass.getTypeName());

//        System.out.println(superclass);
    }
    
    /*
    获取运行时类实现的接口
     */
    
    @Test
    public void test4(){
        Class clazz=Person.class;

        Class[] interfaces = clazz.getInterfaces();
        for (Class c : interfaces) {
            System.out.print(c+"\t");
        }
        System.out.println();

        Class[] interfaces1 = clazz.getSuperclass().getInterfaces();

        for (Class c : interfaces1) {
            System.out.print(c);
        }


    }
    /*
    获取运行时类的所在的包
     */

    @Test
    public void test5(){
        Class clazz=Person.class;
        Package clazzPackage = clazz.getPackage();
        System.out.println(clazzPackage);
    }

/*
    获取运行时类声明的注解
     */

    @Test
    public void test6(){
        Class clazz=Person.class;

        Annotation[] annotations = clazz.getAnnotations();
        for(Annotation annos:annotations){
            System.out.println(annos);
        }

    }
}
