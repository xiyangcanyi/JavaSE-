package com.atguigu.java2;

import com.atguigu.java1.Person;
import org.junit.Test;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 *获取运行时类的方法结构
 *
 *
 * @author zyp
 * @create 2023-02-13 22:17
 */
public class MethodTest {

    @Test
    public void test1(){

        Class<Person> clazz = Person.class;

//      getMethods():获取当前运行类及其父类中声明为的public访问权限方法
        Method[] methods = clazz.getMethods();
        for (Method method : methods) {
            System.out.println(method);
        }
        System.out.println();
//        getDeclareMethods():获取当前运行时类中声明的所有方法.(不包含父类的方法)
        Method[] declaredMethods = clazz.getDeclaredMethods();
        for (Method declaredMethod : declaredMethods) {
            System.out.println(declaredMethod);
        }
    }
    /*
    @Xxxxx
    权限修饰符  返回值类型   方法名（参数类型1 形参名，...）{
    }
     */
    @Test
    public  void test2(){
//        1.获取方法生命的注解
        Class<Person> clazz = Person.class;
        Method[] declaredMethods = clazz.getDeclaredMethods();
        for (Method method : declaredMethods) {
//            
//            System.out.println(declaredMethod);
//            1.获取方法声明的注解
            Annotation[] annotations = method.getAnnotations();
            for(Annotation annotation:annotations){
                System.out.print(annotation+"\t");
            }
//            System.out.println();
//            2.权限修饰符
            String modifier = Modifier.toString(method.getModifiers());
            System.out.print(modifier+"\t");
//            System.out.println();
//            3.返回值类型
            System.out.print(method.getReturnType().getName()+"\t");


//            4.方法名：
            System.out.print(method.getName());
            System.out.print("(");

//            5.形参列表
            Class<?>[] parameterTypes = method.getParameterTypes();
            if (!(parameterTypes==null && parameterTypes.length==0)){
//                for (Class type : parameterTypes) {
//                    System.out.print(type.getName()+"args_"+type.getTypeName());
//                }
                for (int i = 0; i < parameterTypes.length; i++) {
                    if (i== parameterTypes.length-1){
                        System.out.print(parameterTypes[i].getName()+"\t"+"args_"+i);
                        break;
                    }
                    System.out.print(parameterTypes[i].getName()+"\t"+"args_"+i+",");
                }
            }

            System.out.print(")");

//            6.抛出的异常
            Class<?>[] exceptionTypes = method.getExceptionTypes();
//            if (!(exceptionTypes==null && exceptionTypes.length==0)){
//                System.out.print(" throws ");
//                for (int i = 0; i < exceptionTypes.length; i++) {
//                    if (i==exceptionTypes.length-1){
//                        System.out.print(exceptionTypes[i].getName());
//                        break;
//                    }
//                    System.out.print(exceptionTypes[i].getName()+",");
//                }
//            }
            if (exceptionTypes.length>0){
                System.out.print(" throws ");
                for (int i = 0; i < exceptionTypes.length; i++) {
                    if (i==exceptionTypes.length-1){
                        System.out.print(exceptionTypes[i].getName());
                        break;
                    }
                    System.out.print(exceptionTypes[i].getName()+",");
                }
            }

            System.out.println();
        }

    }



}
