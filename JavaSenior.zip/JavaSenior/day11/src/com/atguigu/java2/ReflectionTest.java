package com.atguigu.java2;

import com.atguigu.java1.Person;
import org.junit.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * 调用运行时类中的指定结构：属性、方法、构造器
 *
 * @author zyp
 * @create 2023-02-14 11:21
 */
public class ReflectionTest {
    /*

     */

    @Test
    public void testField() throws Exception {
        Class clazz = Person.class;

//        获取运行时类的对象
        Person p = (Person) clazz.newInstance();


//        获取指定的属性，要求运行时的类中属性声明为public
        Field id = clazz.getField("id");

    /*
           设置当前属性的值
           set()；参数1：指明设置那个对象的属性  参数2：将此属性值设置为多少
     */

        id.set(p,1001);

        /*
        获取当前属性的值
        get():参数1：获取哪个对象的当前属性值
         */
        int pId = (int)id.get(p);
        System.out.println(pId);


    }
    /*
    如何操作运行时类中的指定的属性---需要掌握
     */

    @Test
    public void testField1() throws Exception{
        Class clazz=Person.class;
//        创建运行时类的对象
        Object p1 = clazz.newInstance();
//getDeclaredField（String name）：获取运行时类中的指定变量名的属性
        Field age = clazz.getDeclaredField("age");
//     保证当前属性是可访问的
        age.setAccessible(true);
        age.set(p1,123);

        System.out.println(p1);


    }

    /*
    如何操作运行时类中的指定的方法---需要掌握
     */

    @Test
    public void testMethod() throws Exception{

        Class clazz=Person.class;
//        创建运行时类的对象
        Person p1 = (Person) clazz.newInstance();

//        获取指定的某个方法
//        getDeclaredMthod():参数：指明获取方法的名称  参数2：指明获取方法的形参列表
        Method show = clazz.getDeclaredMethod("show", String.class);
//        保证当前方法是可访问的
        show.setAccessible(true);

        /*
        invoke():参数1：方法的调用者，   参数2：给方法的形参赋值的实参
        invoke()的返回值即为对应类中调用的方法返回值
         */
        Object chn = show.invoke(p1, "CHN");
        System.out.println(chn);

//        System.out.println(show);

        System.out.println("***************************");

        Method showDesc = clazz.getDeclaredMethod("showDesc");
        showDesc.setAccessible(true);

//       如果调用的运行时的类没有返回值，则invoke（）返回null
//        Object returnVal = showDesc.invoke(p1);
        Object returnVal = showDesc.invoke(Person.class);
        System.out.println(returnVal);

    }

     /*
    如何操作运行时类中的指定的方法
     */

    @Test
    public void testConstructor() throws Exception{
        Class clazz=Person.class;
//        创建运行时类的对象
//        Person p1 = (Person) clazz.newInstance();

        /*
        private Person(String name);
        1.获取指定的构造器
        getDeclaredConstructor（）：参数：指明构造器的参数列表
         */

        Constructor constructor = clazz.getDeclaredConstructor(String.class);

//        保证此构造器是可访问的
        constructor.setAccessible(true);
//      调用构造器创建对象
        Person tom = (Person) constructor.newInstance("Tom");

        System.out.println(tom);

    }



}
