package com.atguigu.java1;

/**
 * @author zyp
 * @create 2023-02-13 21:41
 */
public interface MyInterface {
    void info();
}
