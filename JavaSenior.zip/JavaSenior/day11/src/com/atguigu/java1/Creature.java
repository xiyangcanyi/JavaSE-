package com.atguigu.java1;

import java.io.Serializable;

/**
 * @author zyp
 * @create 2023-02-13 21:36
 */
public class Creature<T> implements Serializable {
    private static final long serialVersionUID=43827493212219198L;

    private char gender;
    public double weight;

    public void breath(){
        System.out.println("生物呼吸!");

    }
    public void eat(){
        System.out.println("生物吃东西!");
    }
}
