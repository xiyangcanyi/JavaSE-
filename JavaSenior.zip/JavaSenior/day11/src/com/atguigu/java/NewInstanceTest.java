package com.atguigu.java;

import org.junit.Test;

import java.util.Random;

/**
 * @author zyp
 * @create 2023-02-13 20:31
 */
public class NewInstanceTest {

    @Test
    public void test1() throws InstantiationException, IllegalAccessException {
        Class<Person> clazz = Person.class;

        Person p = clazz.newInstance();
        System.out.println(p);//调用此方法,创建对应的运行时类的对象.内部调用了运行时类的空参构造器

        /*
        要想此方法正常创建运行时类的对象,要求:
          1.运行时类必须提供空参构造器
          2.空参构造器的访问权限得够.通常设置为public

          在javabean中要求提供一个public空参构造器.原因是
          1.便于通过反射,创建运行时类的对象
          2.便于子类继承此运行时类时,默认调用super()时,保证父类由此构造器

          */
    }

    @Test
    public void test2()  {
        for (int i = 0; i < 100; i++) {
            Random random = new Random();
            int num = random.nextInt(3);//0,1,2
            String classPath = "";
            switch (num) {
                case 0:
                    classPath = "java.util.Date";
                    break;
                case 1:
                    classPath = "java.sql.Date";
                case 2:
                    classPath = "com.atguigu.java.Person";
            }

            try {
                System.out.println(getInstance(classPath));
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }


    }

    /*
    创建一个指定类的对象
    classPath:指定类的全类名
     */
    public Object getInstance(String classPath) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class clazz = Class.forName(classPath);
        return clazz.newInstance();


    }

}
