package com.atguigu.java;

/**
 * 多线程的创建，方式一：继承Thread类方式
 * 1.创建一个继承于Thread类的子类
 * 2.重写Thread类的run()    -->将此线程执行的操作声明在run()中
 * 3.创建Thread类的子类对象
 * 4.通过此对象调用start（）
 *
 *说明两个问题：
 * 问题一：我们启动一个线程，必须调用start（），不能调用run（）的方式启动线程
 * 问题二：如果再启动一个线程，必须重新创建一个Thread子类的对象，调用此对象的start（）
 *
 * <p>
 *     例子：遍历100以内的所有的偶数
 * </p>
 * @author zyp
 * @create 2023-01-27 14:46
 */

//1.1.创建一个继承于Thread类的子类
public class ThreadTest{
    public static void main(String[] args) {
//        3.创建Thread类的子类对象
        MyThread thread = new MyThread();
//        * 4.通过此对象调用start（） ①启动当前线程 ②调用当前线程的run()
        thread.start();
//       现在只是当前对象调用方法，只是单线程，不是多线程
//        thread.run();
        System.out.println("hello"+"**************");
//        问题二：哉启动一个线程，遍历100以内的偶数。不可以还让已经start（）的线程去执行。
//        会报IllegalThreadStatusException的异常
//        thread.start();
//  需要重新创建一个线程的对象
        MyThread t2 = new MyThread();
        t2.start();

//        如下操作仍然是在main线程中执行
        for (int i = 0; i < 100; i++) {
            if (i%2!=0){
                System.out.println(Thread.currentThread().getName()+i+"********main*****");
            }
        }
    }

}
class MyThread extends Thread{
//    2.重写Thread类的run()
    @Override
    public void run() {
        for (int i = 0; i < 100; i++) {
            if (i%2==0){
                System.out.println(Thread.currentThread().getName()+":"+i);
            }
        }
    }
}



