package com.atguigu.java;
/*
程序（programmer）：一段静态的代码
进程（process）：程序的按指定路径执行或者正在运行的一个程序，进程是作为资源分配的单位
线程（thread）：一个进程有多个线程，每个线程拥有独立的运行栈和程序计数器（PC），线程作为调度和执行的单位

并行：多个CPU同时执行多个任务。
并发：一个CPu（采用时间片）同时执行多个任务。比如：同一时间间隔内：多个人做同一件事

 */
import java.util.Arrays;

public class HelloJava {
    static int num=10;
    public static void main(String[] args) {
        System.out.println("hellojava!");
        System.out.println("HelloJava.main");
        System.out.println("args = " + Arrays.deepToString(args));
        System.out.println("num = " + num);
    }

}
