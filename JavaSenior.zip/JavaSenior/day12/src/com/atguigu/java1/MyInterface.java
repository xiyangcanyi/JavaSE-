package com.atguigu.java1;

/**
 * @author zyp
 * @create 2023-02-14 17:05
 */
@FunctionalInterface
public interface MyInterface {
    void method1();
//    void method2();
}
