package com.atguigu.java2;

/**
 * @author zyp
 * @create 2023-02-11 11:59
 */
public class Student extends Person{
}
