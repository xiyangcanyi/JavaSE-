package com.atguigu.exer;

/**
 * 定义一个Employee类。
 *  该类包含：private成员变量name,age,birthday，其中 birthday 为 MyDate 类的对象；
 *  并为每一个属性定义 getter, setter 方法；
 *  并重写 toString 方法输出 name, age, birthday
 *
 *
 * @author zyp
 * @create 2023-02-09 22:01
 */
public class Employee implements Comparable<Employee>{
    private String name;
    private int age;
    private MyDate birthday;

    public Employee() {
    }

    public Employee(String name, int age, MyDate birthday) {
        this.name = name;
        this.age = age;
        this.birthday = birthday;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setBirthday(MyDate birthday) {
        this.birthday = birthday;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public MyDate getBirthday() {
        return birthday;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", birthday=" + birthday +
                '}';
    }

    @Override
    public int compareTo(Employee o) {
        return this.name.compareTo(o.name);
    }
//没有指明泛型时的写法
//    @Override
//    public int compareTo(Employee o) {
//        if (o instanceof Employee){
//            Employee e=(Employee) o;
//            int year = this.getBirthday().getYear() - ((Employee) o).getBirthday().getYear();
//            if (year!=0){
//                return year;
//            }
//            int month = this.getBirthday().getMonth() - ((Employee) o).getBirthday().getMonth();
//            if (month!=0){
//                return month;
//            }
//            return  this.getBirthday().getDay()-((Employee) o).getBirthday().getDay();
//
//
//
//        }
//        throw new RuntimeException("输入数据不一致！");
//    }
}
