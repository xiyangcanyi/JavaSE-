package com.atguigu.java1;

import org.junit.Test;

import java.util.List;

/**
 * @author zyp
 * @create 2023-02-11 10:44
 */
public class DAOTest {
    @Test
    public void test(){
        CustomerDAO dao1=new CustomerDAO();
//        dao1.add(new Customer());

        List<Customer> list=dao1.getForList(10);

        StudentDAO s1=new StudentDAO();
        Student[] student = s1.getIndex(1);

        s1.add(new Student());

    }
}
