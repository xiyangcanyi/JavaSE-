package com.atguigu.java1;

import java.util.List;

/**
 * ORM思想（数据库中的表和Java中的类对应）
 *
 *
 * @author zyp
 * @create 2023-02-11 10:34
 * <p>
 * DAO：data(base) access Object:数据访问对象
 */
public class DAO<T> {//操作表的普遍操作
    //    操作数据库的属性
//    添加一条记录
    public void add(T t) {

    }

    //    删除一条记录
    public boolean remove(int index) {
        return false;
    }


    //   修改一条记录
    public void update(int index, T t) {

    }

    //    查询一条记录
    public T[] getIndex(int index) {
        return null;
    }

    //    查询多条数据
    public List<T> getForList(int index) {
        return null;
    }
//泛型方法
//    举例：返回表中多少条数据记录？整型，获取最大员工入职时间？Date，
    public <E> E getValue(){
        return null;
    }

}
