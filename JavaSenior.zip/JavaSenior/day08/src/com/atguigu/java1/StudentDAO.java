package com.atguigu.java1;

/**
 * @author zyp
 * @create 2023-02-11 10:46
 */
public class StudentDAO extends DAO<Student>{//只能操作某一个表
}
