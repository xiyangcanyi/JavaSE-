package com.atguigu.java1;

/**
 * @author zyp
 * @create 2023-02-11 10:46
 */
public class Student {
}
