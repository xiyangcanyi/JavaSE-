package com.atguigu.java1;

/**
 * @author zyp
 * @create 2023-02-11 10:39
 */
public class Customer {  //此类对应数据库中的customers表

}
