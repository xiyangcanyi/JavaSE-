package com.atguigu.java;

/**
 * @author zyp
 * @create 2023-02-11 9:49
 */
//异常类不能声明为泛型的
public class MyException extends Exception {
}
