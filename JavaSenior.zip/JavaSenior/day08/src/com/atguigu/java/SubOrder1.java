package com.atguigu.java;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zyp
 * @create 2023-02-10 22:49
 */
public class SubOrder1<T> extends Order<T>{
    public static  <E> List<E> copyFromArrayList(E[] arr){
        ArrayList<E> list=new ArrayList<>();
        for (E e:arr) {
            list.add(e);
        }
        return list;
    }
}
