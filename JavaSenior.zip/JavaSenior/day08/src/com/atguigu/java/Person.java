package com.atguigu.java;

/**
 * @author zyp
 * @create 2023-02-11 9:49
 */
public class Person {
}
