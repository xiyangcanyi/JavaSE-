package com.atguigu.java;

/**
 * @author zyp
 * @create 2023-02-10 22:44
 */
public class SubOrder extends Order<Integer>{

}
