package com.atguigu.java1;

import org.junit.Test;

import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;

/**
 *UDP协议的网络编程
 *
 * @author zyp
 * @create 2023-02-13 11:57
 */
public class UDPTest {

    @Test
    public void sender()  {
        DatagramSocket socket= null;
        try {
            socket = new DatagramSocket();
            String str="我是UDP方式发送的导弹";
            byte[] data = str.getBytes(StandardCharsets.UTF_8);
            InetAddress inet = InetAddress.getLocalHost();
            DatagramPacket packet=new DatagramPacket(data,0,data.length,inet,9090);
            socket.send(packet);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            socket.close();
        }


    }

    @Test
    public void receiver()  {

        DatagramSocket socket= null;
        try {
            socket = new DatagramSocket(9090);

            byte[] buffer=new byte[100];

            DatagramPacket packet = new DatagramPacket(buffer,0,buffer.length);
            socket.receive(packet);

            System.out.println(new String(packet.getData(),0, packet.getLength()));
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
        }
        socket.close();

    }
}
