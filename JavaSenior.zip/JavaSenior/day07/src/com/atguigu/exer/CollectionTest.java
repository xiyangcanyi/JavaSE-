package com.atguigu.exer;






import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @author zyp
 * @create 2023-02-09 17:40
 */
public class CollectionTest {
    @Test
    public void test1(){
        Collection coll=new ArrayList();
        coll.add(123);
        coll.add(456);
        coll.add("AA");
        coll.add(false);
        coll.add(new Person("Tom",12));
        coll.forEach(System.out::println);
//        coll.add(123);
    }
}
