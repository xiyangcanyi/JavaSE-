package com.atguigu.java;

import org.junit.jupiter.api.Test;

import java.util.*;

/**
 * @author zyp
 * @create 2023-02-10 14:37
 */
public class TreeMapTest {

//    向TreeMap中添加key-value，要求key必须是由同一个类创建的对象
//    因为要按照key进行排序：自然排序和定制排序

    @Test
    public void test1(){
        TreeMap map=new TreeMap();
        User u1 = new User("Tom", 12);
        User u2 = new User("Jerry", 45);
        User u3 = new User("Jack", 23);
        User u4 = new User("Rose", 16);
        map.put(u1,98);
        map.put(u2,89);
        map.put(u3,100);
        map.put(u4,76);
        for (Object o : map.entrySet()) {
            Map.Entry map1=(Map.Entry) o;
            System.out.println(map1.getKey() +"-------"+ map1.getValue());
        }


    }
    @Test
    public void test2(){

        TreeMap map=new TreeMap(new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                if (o1 instanceof User && o2 instanceof User){
                    User u1=(User) o1;
                    User u2=(User) o2;
                    return -Integer.compare(u1.getAge(),u2.getAge());
                }
                throw new RuntimeException("传入数据不一致!");
            }
        });
        User u1 = new User("Tom", 12);
        User u2 = new User("Jerry", 45);
        User u3 = new User("Jack", 23);
        User u4 = new User("Rose", 16);
        map.put(u1,98);
        map.put(u2,89);
        map.put(u3,100);
        map.put(u4,76);
//
        Iterator iterator1 = map.keySet().iterator();
        while (iterator1.hasNext()){


            Object obj = iterator1.next();
            Object value = map.get(obj);
            System.out.println(obj+"------"+value);
        }
//        for (Object o : map.entrySet()) {
//            Map.Entry map1=(Map.Entry) o;
//            System.out.println(map1.getKey() +"-------"+ map1.getValue());
//        }
    }

}
