package com.atguigu.java;

import org.junit.Test;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * @author zyp
 * @create 2023-02-10 15:07
 */
public class PropertiesTest {
//    Properties:常用来处理配置文件。key-value都是String类型
    @Test
    public void test1() throws Exception {
        FileInputStream file=null;
        try {
            Properties pros=new Properties();
            file = new FileInputStream("E:\\WorkSpaceIdea\\JavaSenior\\jdbc.properties");
            pros.load(file);//加载流对应的文件
            String name = pros.getProperty("UserName");
            String password = pros.getProperty("Password");
            System.out.println("name"+name+" ,password "+password);
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (file!=null)
               file.close();
        }


    }
}

