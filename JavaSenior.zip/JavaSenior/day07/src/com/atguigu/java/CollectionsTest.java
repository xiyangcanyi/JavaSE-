package com.atguigu.java;

import org.junit.Test;

import java.util.*;

/**
 * Collections:操作Collection、Map的工具类
 *
 * 面试题：Collection 和 Collections的区别？
 *Collection是操作集合的接口，Collections是工具类
 *
 *
 * @author zyp
 * @create 2023-02-10 17:47
 */
public class CollectionsTest {

    /*
reverse(List)：反转 List 中元素的顺序
shuffle(List)：对 List 集合元素进行随机排序
sort(List)：根据元素的自然顺序对指定 List 集合元素按升序排序
sort(List，Comparator)：根据指定的 Comparator 产生的顺序对 List 集合元素进行排序
swap(List，int， int)：将指定 list 集合中的 i 处元素和 j 处元素进行交换

Object max(Collection)：根据元素的自然顺序，返回给定集合中的最大元素
Object max(Collection，Comparator)：根据 Comparator 指定的顺序，返回给定集合中的最大元素
Object min(Collection)
Object min(Collection，Comparator)
int frequency(Collection，Object)：返回指定集合中指定元素的出现次数
void copy(List dest,List src)：将src中的内容复制到dest中
boolean replaceAll(List list，Object oldVal，Object newVal)：使用新值替换 List 对象的所有旧值

 */
    @Test
    public void test2(){
        ArrayList list = new ArrayList();
        list.add(123);
        list.add(0);
        list.add(43);
        list.add(96);
        list.add(-1);
//      报异常：IndexOutofBoundsException（"Source does not fit in dest"）
//        List dest=new ArrayList();
//        Collections.copy(dest,list);
//        System.out.println(dest);
//      正确的
        List dest= Arrays.asList(new Object[list.size()]);
        System.out.println(dest.size());
        Collections.copy(dest,list);
        System.out.println(dest);

        /*
        Collections 类中提供了多个 synchronizedXxx() 方法，
        该方法可使将指定集合包装成线程同步的集合，从而可以解决
        多线程并发访问集合时的线程安全问题
       将 ArrayList、HashTable、HashSet创建的线程不安全的对象转化为线程安全的
         */
//      返回的list1即为线程安全的List
//        Collection list1 = Collections.synchronizedCollection(list);
        List list1 = Collections.synchronizedList(list);


    }

    @Test
    public void test1(){
        ArrayList list = new ArrayList();
        list.add(123);
        list.add(123);
        list.add(123);

        list.add(0);
        list.add(43);
        list.add(96);
        list.add(-1);

        System.out.println(list);

//        Collections.reverse(list);

//        Collections.shuffle(list);
        //       自然排序
//        Collections.sort(list);

        System.out.println(list);
//        定制排序
//        Collections.sort(list, new Comparator<Integer>() {
//            @Override
//            public int compare(Integer o1, Integer o2) {
//              return   Integer.compare(o1,o2);
//            }
//
//        });
//        System.out.println(list);
//        Collections.swap(list,0,1);
//        for (int i = 0; i < list.size(); i++) {
//            System.out.println(Collections.frequency(list,list.get(i)));
//        }
        System.out.println(list);

    }
}
