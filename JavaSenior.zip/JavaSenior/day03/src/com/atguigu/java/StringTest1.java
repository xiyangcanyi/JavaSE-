package com.atguigu.java;

import org.junit.Test;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;

/**
 * 涉及到String类与其他结构之间的转换
 *
 *
 * @author zyp
 * @create 2023-02-01 19:09
 */
public class StringTest1 {

    @Test
    public void test4(){}
    /*
    String 与byte[]之间的转换
    String---->char[]:调用String的getBytes()方法
    char[]-->String:调用String的构造器

    编码：字符串--->字节（看得懂---->看不懂的二 进制数据）
    解码：编码的逆过程字节----> 字符串  看不懂的二进制数据--->看得懂

    说明：解码时，要求解码使用的字符集必须与编码时使用费的字符集一致。否则会出现乱码。


     */
    @Test
    public void test3(){
        String str1="abc123中国";
        byte[] bytes = str1.getBytes();//使用默认的字符集，进行转换
        System.out.println(Arrays.toString(bytes));
        byte[] gbks=null;
        try {
            gbks = str1.getBytes("gbk");//使用gbk字符进行编码
            System.out.println(Arrays.toString(gbks));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        String s2 = new String(bytes);
        System.out.println(s2);
        String str3 = new String(gbks);
        System.out.println(str3);//abc123�й�   出现乱码。原因：编码集和解码集不一致！
        try {
            String str4 = new String(gbks, "gbk");
            System.out.println(str4);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }


    }


//     String与char[]之间的转换
    /*
    String---->char[]:调用String的toCharAarray()
    char[]-->String:调用String的构造器


     */
    @Test
    public void test2(){
        String str1="abc123";//题目：a21cb3
        char[] charArray = str1.toCharArray();
        for (int i = 0; i < charArray.length; i++) {
            System.out.println(charArray[i]);
        }
        char[] arr=new char[]{'h','e','l','l','o'};
        String s1 = new String(arr);
        System.out.println(s1);
    }

    /*
    复习：
    String 与基本数据类型、包装类之间的转换
    String-->基本数据类型、包装类：调用包装类的静态方法：parseXxx（str）
    基本数据类型、包装类 --> 调用String重载的valueOf(xxx)


     */
    @Test
    public void test1(){
        String str1="123";
//        int num=(int)str1;错误的
        int num = Integer.parseInt(str1);
        int num1=123;
        String s = String.valueOf(123);
        String s1 = num + "";

        System.out.println(s1==str1);
    }
}
