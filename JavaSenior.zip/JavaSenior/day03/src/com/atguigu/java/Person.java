package com.atguigu.java;

/**
 * @author zyp
 * @create 2023-02-01 14:35
 */
public class Person {
    String name;
    int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public Person() {
    }
}
