package com.atguigu.java1;

import java.lang.annotation.*;

import static java.lang.annotation.ElementType.*;

/**
 * @author zyp
 * @create 2023-02-06 0:18
 */
//指定注解的生命周期
@Inherited
@Repeatable(MyAnnotations.class)
@Retention(RetentionPolicy.RUNTIME)
@Target({TYPE,FIELD, METHOD, PARAMETER, CONSTRUCTOR,  LOCAL_VARIABLE ,TYPE_PARAMETER,TYPE_USE})

public @interface MyAnnotation {
    String value() default "hello";
}


