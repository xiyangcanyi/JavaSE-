package com.atguigu.java;

import java.util.ArrayList;
import java.util.HashSet;

/**
 * @author zyp
 * @create 2023-01-31 17:41
 */
public class Solution {
    public void Permutations(ArrayList<String> list) {

        Object[] array =  list.toArray();
//        int cnt=0;
        HashSet<String> set = new HashSet<String>();
        


        System.out.println(list);
    }
}
class Test{
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<String>();
        list.add("['a','b','cd']");
        list.add("['de']");
        list.add("['e','f']");
        Solution solution = new Solution();

        solution.Permutations(list);
        Object[] array = list.toArray();




    }
}