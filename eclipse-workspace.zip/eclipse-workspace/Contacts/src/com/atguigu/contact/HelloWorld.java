

package com.atguigu.contact;
/**
 * 
 * @Description 这是我的第一个程序
 * @author zyp   Email:1521165790@qq.com
 * @version v1.0
 * @data 2022年12月4日下午4:21:44
 */
public class HelloWorld {
	/**
	 * 
	 * @Description
	 * @author zyp
	 * @data 2022年12月4日下午4:22:28
	 * @param args
	 */
	
	public static void main(String args[]) {
		
		System.out.println("helloworld!");
	}
}
