package com.atguigu.contact;
/**
 * 
 * @Description
 * @author zyp   Email:1521165790@qq.com
 * @version
 * @data 2022年12月4日下午4:21:27
 */
public class Hello {
	public Hello() {
		// TODO Auto-generated constructor stub
	}

}
