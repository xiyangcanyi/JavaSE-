package com.atguigu.exer1;

public class CommonEmployee extends Employee{
	@Override
	public void work() {
		// TODO Auto-generated method stub
		System.out.println("员工在一线车间生产产品");
	}
}
