package com.atguigu.java8;

public interface CompareB {
	default void method3() {
		System.out.println("CompareB:上海");
	}
	
	
	
}
