package com.atguigu.java8;

public class SuperClass {
	public void method3(){
		System.out.println("SuperClass:北京");
	}
}
