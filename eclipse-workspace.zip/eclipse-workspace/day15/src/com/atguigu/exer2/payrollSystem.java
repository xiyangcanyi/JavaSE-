package com.atguigu.exer2;

import java.util.Calendar;
import java.util.Scanner;

public class payrollSystem {
	public static void main(String[] args) {
//		方式一：
//		Scanner scanner = new Scanner(System.in);
//		System.out.println("请输入当月的月份：");
//		int month = scanner.nextInt();
//		方式二
		Calendar calendar = Calendar.getInstance();
		int month = calendar.get(Calendar.MONTH);//获取当前的月份
		System.out.println(month);//1-12月份： 0-11表示。
		
		Employee[] emp=new Employee[2];
		emp[0]=new SalariedEmployee("马森", 1002,new MyDate(1992, 2, 28),10000);
		emp[1]=new HourlyEmployee("panyusheng",2001 , new MyDate(1991, 1, 6),60,240);
		
		for (int i = 0; i < emp.length; i++) {
			System.out.println(emp[i]);
			double salary = emp[i].earnings();
			System.out.println("月工资为："+salary);
			if(emp[i].getBirthday().getMonth()==(month+1)) {
				System.out.println("生日快乐！奖励100元");
				salary+=100;
			}
//			System.out.println("月工资为："+salary);
		}
		
		
		
	}
}
