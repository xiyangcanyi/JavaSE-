package com.atguigu.exer2;

public class SalariedEmployee extends Employee{
	private double monthlySalary;//月工资
	public SalariedEmployee(String name, int number, MyDate birthday) {
		super(name, number, birthday);
		
		// TODO Auto-generated constructor stub
	}
	public SalariedEmployee(String name, int number, MyDate birthday,double monthlySalary) {
		super(name, number, birthday);
		this.monthlySalary=monthlySalary;
		// TODO Auto-generated constructor stub
	}
	
	public double getMonthlySalary() {
		return monthlySalary;
	}


	public void setMonthlySalary(double monthlySalary) {
		this.monthlySalary = monthlySalary;
	}


	@Override
	public double earnings() {
		return monthlySalary;
	}
	public String toString() {
		return "SaslariedEmployee["+super.toString()+"]";
	}
}
