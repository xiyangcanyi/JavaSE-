package com.atguigu.exer3;

public class CompareCircleTest {
	public static void main(String[] args) {
		CompareableCircle c1 = new CompareableCircle(3.4);
		CompareableCircle c2 = new CompareableCircle(3.6);
		int compareValue = c1.compareTo(c2);
		System.out.println(compareValue);
		if (compareValue>0) {
			System.out.println("c1对象大");
		}else if (compareValue < 0) {
			System.out.println("c2对象大");
		}else {
			System.out.println("两个对象相等");
		}
		int compareValue1=c1.compareTo(new String("AA"));
		System.out.println(compareValue1);
	}
}
