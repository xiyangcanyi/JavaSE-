package com.leetcode.java;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

import javax.net.ssl.SSLContext;

//import java.util.HashMap;
//import java.util.Map;
//import java.util.Scanner;

/**
 * 两数之和
 * 
 * @Description
 * @author zyp Email:1521165790@qq.com
 * @version
 * @data 2023年1月6日下午5:12:23
 */

public class TwoNumberSum {
	public static void main(String[] args) {
		TwoNumberSum test = new TwoNumberSum();
		int[] nums = { 7, 6, 4, 3, 1 };
//		test.twoSum(nums, 6);
		System.out.println(Arrays.toString(test.twoSum(nums, 6)));
		String s = "()";
		System.out.println(test.isValid(s));
		System.out.println(test.maxSubArray(nums));
		int[] prices= {8,9,3,5,1,3};
		System.out.println(test.tradeStock(prices,3));
		int[] nums1 = { 3, 2, 3 };
		System.out.println("*************");
//		String s1 ="abcabcbb";
//		test.lengthOfLongestSubstring(s1);
//		System.out.println(test.getMaxFillWater(nums));
		int[] height = { 1, 8, 6, 2, 5, 4, 8, 3, 7 };
//		System.out.println(test.getMaxFillWater(height));
		System.out.println(test.search(height, 3));
//		System.out.println(test.moreElement(nums1));
	}

//	public int[] twoSum(int[] nums, int target) {
////		int[] sums;
//		Map<Integer, Integer>map=new HashMap<>();
//		for (int i = 0; i < nums.length; i++) {
//			if (map.containsKey(target-nums[i])) {
//				return new int[] {map.get(target-nums[i]),i};
//			}
//			map.put(nums[i], i);
//		}
//		return new int[0];
//		
//	
//		
//	}
	/**
	 * 两数之和的暴力解法
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月6日下午5:12:46
	 * @param nums
	 * @param target
	 * @return
	 */
	public int[] twoSum(int[] nums, int target) {
		int[] result = new int[2];
		for (int i = 0; i < nums.length - 1; i++) {
			int sum = 0;
			for (int j = 1; j < nums.length; j++) {
				if (j > i) {

					sum = nums[i] + nums[j];
					if (target == sum) {
						result[0] = i;
						result[1] = j;

					}
				}

			}

		}
		return result;
	}

	/**
	 * 有效的括号
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月6日下午5:11:32
	 * @param s
	 * @return
	 */
	public boolean isValid(String s) {
//		for (int i = 0; i < s.length(); i++) {
//			while(s.charAt(i)=='(') {
//				
//			}
//		}
		Stack<Character> stack = new Stack<>();
		char[] charArray = s.toCharArray();
		for (char c : charArray) {
			if (c == '(' || c == '{' || c == '[') {
				stack.push(c);
			} else {
				if (!stack.isEmpty()) {
					if (c == ')') {
						if (stack.pop() != '(')
							return false;
					} else if (c == '}') {
						if (stack.pop() != '{')
							return false;

					} else {
						if (stack.pop() != '[')
							return false;

					}
				}

				else {
					return false;
				}

			}
		}
		return stack.isEmpty();

	}

	/**
	 * 合并两个有序链表
	 * 
	 * @Description
	 * @author zyp Email:1521165790@qq.com
	 * @version
	 * @data 2023年1月6日下午5:10:47
	 */
	// Definition for singly-linked list.
	public class ListNode {
		int val;
		ListNode next;

		ListNode() {
		}

		ListNode(int val) {
			this.val = val;
		}

		ListNode(int val, ListNode next) {
			this.val = val;
			this.next = next;
		}
	}

	public ListNode MergeLinkedList(ListNode l1, ListNode l2) {

		ListNode prehead = new ListNode(-1);
		ListNode prev = prehead;
		while (l1 != null && l2 != null) {
			if (l1.val <= l2.val) {
				prev.next = l1;
				l1 = l1.next;
			} else {
				prev.next = l2;
				l2 = l2.next;
			}
			prev = prev.next;
		}
		// 合并后 l1 和 l2 最多只有一个还未被合并完，我们直接将链表末尾指向未合并完的链表即可
		prev.next = (l1 == null) ? l2 : l1;

		return prehead.next;
	}

	public ListNode mergedList(ListNode l1, ListNode l2) {
		if (l1 == null) {
			return l2;
		}
		if (l2 == null) {
			return l1;
		}
		if (l1.val < l2.val) {
			mergedList(l1.next, l2);
			return l1;
		} else {
			mergedList(l1, l2.next);
			return l2;
		}
	}

	/**
	 * 最大子数组的和
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月6日下午5:10:12
	 * @param arr
	 * @return
	 */
	public int maxSubArray(int[] arr) {
		int pre = 0;
		int max = arr[0];
		for (int i = 0; i < arr.length; i++) {
			pre = Math.max(arr[i] + pre, arr[i]);
			max = Math.max(pre, max);
		}
		return max;
	}

	public class TreeNode {
		int val;
		TreeNode left;
		TreeNode right;

		public TreeNode() {
			// TODO Auto-generated constructor stub
		}

		TreeNode(int val) {
			this.val = val;

		}

		public TreeNode(int val, TreeNode left, TreeNode right) {
			super();
			this.val = val;
			this.left = left;
			this.right = right;
		}

	}

	/**
	 * 二叉树的中序遍历（递归解法）注意不能直接递归，要通过一个函数（传入集合），不然集合会重复创建
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月6日下午5:09:33
	 * @param root
	 * @return
	 */
//	public List<Integer> inorderTraversal(TreeNode root){
//		ArrayList<Integer> result = new ArrayList<>();
//		
//		return result;
//	}
//	public void infixOrder(TreeNode root,List<Integer> result) {
//		if (root==null) {
//			return;
//		}
//		infixOrder(root.left, result);
//		result.add(root.val);
//		infixOrder(root.right, result);
//	}
	/**
	 * 二叉树的中序遍历（非递归的解法）应用栈的结构进行存储
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月6日下午5:14:34
	 * @param root
	 * @return
	 */
	public List<Integer> inorderTraversal(TreeNode root) {
		ArrayList<Integer> res = new ArrayList<>();
		Deque<TreeNode> stk = new LinkedList<TreeNode>();
		while (root != null || !stk.isEmpty()) {
			while (root != null) {
				stk.push(root);
				root = root.left;
			}
			root = stk.pop();
			res.add(root.val);
			root = root.right;
		}
		return res;
	}

	/**
	 * 
	 * @Description 给你一个二叉树的根节点 root ， 检查它是否轴对称。
	 * @author zyp
	 * @data 2023年1月6日下午5:36:06
	 * @param root
	 * @return
	 */
	public boolean isSymmetric(TreeNode root) {
		return ss(root, root);
	}

	private boolean ss(TreeNode root1, TreeNode root2) {
		// TODO Auto-generated method stub
		if (root1 == null && root2 == null) {
			return true;
		}
		if (root1 == null || root2 == null) {
			return false;
		}
		return root1.val == root2.val && ss(root1.left, root2.left) && ss(root1.right, root2.right);
	}

	/**
	 * 判断二叉树是对称的 或者通过迭代的方式进行，主要通过队列的方式配对 队列Queue<TreeNode> q = new
	 * LinkedList<TreeNode>(); 通过offer或者poll进行进出
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月6日下午5:49:59
	 * @param root
	 * @return
	 */
	public boolean isSymmetrics(TreeNode root) {
		return check(root, root);
	}

	private boolean check(TreeNode root1, TreeNode root2) {
		// TODO Auto-generated method stub
		Queue<TreeNode> q = new LinkedList<TreeNode>();
		q.add(root1);
		q.add(root2);

		while (!q.isEmpty()) {
			root1 = q.remove();
			root2 = q.remove();
			if (root1 == null && root2 == null) {
				continue;
			}
			if ((root1 == null || root2 == null) || (root1.val != root2.val)) {
				return false;
			}
			q.add(root1.left);
		
			q.add(root1.right);

			q.add(root2.left);
			q.add(root2.right);

		}

		return true;
	}

	/**
	 * 二叉树的最大深度（二叉树的深度为根节点到最远叶子节点的最长路径上的节点数。） 通过深度优先遍历进行递归，判断左右的数字那个比较大，记得加上1即可
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月6日下午5:54:10
	 * @param root
	 * @return
	 */
	public int maxDepth(TreeNode root) {
		if (root == null) {
			return 0;
		}
		int leftHeight = maxDepth(root.left);
		int rightHeight = maxDepth(root.right);
		return Math.max(leftHeight, rightHeight) + 1;
	}

	/**
	 * 通过队列的方法进行执行(求最大深度)
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月6日下午5:55:10
	 * @param root
	 * @return
	 */
	public int maxDepth1(TreeNode root) {
		if (root == null) {
			return 0;
		}
		Queue<TreeNode> queue = new LinkedList<TreeNode>();
		queue.offer(root);
		int ans = 0;
		while (!queue.isEmpty()) {
			int size = queue.size();
			while (size > 0) {
				TreeNode node = queue.poll();
				size--;
				if (node.left != null) {
					queue.offer(node.left);

				}
				if (node.right != null) {
					queue.offer(node.right);
				}

			}
			ans++;

		}
		return ans;

	}

	/**
	 * 股票交易的最佳时机
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月6日下午8:39:53
	 * @param price
	 * @return
	 */
	public int tradeStock(int[] prices,int k) {
		int max=0 ;
        int[] profit=new int[k];
		for (int i = 0; i < prices.length-1; i++,--k) {
			max=0;
			for (int j = 0; j < prices.length; j++) {
				if (j > i) {
					if ((prices[j] - prices[i]) > max) {
						max = prices[j] - prices[i];
					}
                    
				}
                profit[k]=max;

			}

		}
        int sum=0;
        for(int i=0;i<k;i++){
            sum+=profit[i];
        }
		return sum;
//		return 0;

	}

	/**
	 * 出现一次的数字
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月6日下午9:01:51
	 * @param nums
	 * @return
	 */
//	public int onlyOne(int[] nums) {
////		HashMap<Integer, Integer> nums = new HashMap<>();
//		for (int i = 1; i < nums.length; i++) {
//			nums[0]^=nums[i];
//		}
//		return nums[0];
//	}
	public int onlyOne1(int[] nums) {
//		HashMap<Integer, Integer> nums = new HashMap<>();
		for (int i = 0; i < nums.length;) {
			if (nums[i] != nums[i + 1]) {
				return nums[i];

			} else {
				i += 2;
			}

		}
		return nums[nums.length - 1];

	}

	public int singleNumber(int[] nums) {
		HashMap<Integer, Integer> map = new HashMap<>();
		for (Integer value : nums) {
			Integer count = map.get(value);
			count = (count == null) ? 1 : ++count;
			map.put(value, count);
		}
		for (Integer key : map.keySet()) {
			Integer count = map.get(key);
			if (count == 1) {
				return key;
			}
		}
		return -1;
	}

	public class ListNode1 {
		int val;
		ListNode1 next;

		public ListNode1() {
			// TODO Auto-generated constructor stub
		}

		public ListNode1(int val) {
			this.val = val;
		}

		public ListNode1(int val, ListNode1 next) {
			this.val = val;
			this.next = next;
		}
	}

	/**
	 * 查找链表中是否存在环（快慢指针法）环形链表
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月6日下午9:25:44
	 * @param head
	 * @return
	 */
//	public boolean checkCycle(ListNode1 head) {
//		if (head == null || head.next == null) {
//			return false;
//		}
//		ListNode slow = head;
//		ListNode fast = head.next;
//		while (slow != fast) {
//			if (fast == null || fast.next == null) {
//				return false;
//			}
//			slow = slow.next;
//			fast = fast.next;
//		}
//		return true;
//	}
//	public boolean checkCycle1(ListNode1 head) {
//		ListNode slow = head;
//		ListNode fast =head;
//		while (fast !=null && fast.next != null) {
//			slow=slow.next;
//			fast=fast.next.next;
//			if (fast==slow) {
//				return true;
//			}
//		}
//		return false;
//	}

	public ListNode1 getIntersectionNode(ListNode1 headA, ListNode1 headB) {
		HashSet<ListNode1> set = new HashSet<>();
		while (headA != null) {
			set.add(headA);
			headA = headA.next;
		}
		while (headB != null) {
			if (set.contains(headB)) {
				return headB;
			} else {
				headB = headB.next;
			}
		}
		return null;
	}

	public ListNode1 jointList(ListNode1 head1, ListNode1 head2) {
		if (head1 == null || head2 == null) {
			return null;
		}
		while (head1 != null) {
			while (head2 != null) {
				if (head1 == head2) {
					return head1;
				} else {
					head2 = head2.next;
				}
			}
			head1 = head1.next;
		}
		return null;
	}

	/**
	 * 出现最多的元素
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月7日上午10:24:06
	 * @param nums
	 * @return
	 */

	public int moreElement(int[] nums) {
		HashMap<Integer, Integer> map = new HashMap<>();
		for (Integer value : nums) {
			Integer count = map.get(value);
			count = (count == null) ? 1 : ++count;
		}
		for (Integer key : map.keySet()) {
			Integer count = map.get(key);
			if (count > (nums.length / 2)) {
				return key;
			}
		}
		return 0;
	}

	public void majorityElement(int[] nums) {
		HashMap<Integer, Integer> map = new HashMap<>();
		for (int num : nums) {
			if (!map.containsKey(num)) {
				map.put(num, 1);
			} else {
				map.put(num, map.get(num) + 1);
			}
		}
	}

	public ListNode1 reverseListNode(ListNode1 head) {
		ListNode1 pre = head.next, r;
		head.next = null;
		while (pre != null) {
			r = pre.next;
			pre.next = head.next;
			head.next = pre;
			pre = r;
		}
		pre = head.next;
		ListNode1 q = pre;
		head.next = null;
		while (q.next != null) {
			r = q.next;
		}
		q.next = head;

		return pre;// 1 5 4 3 2
	}

	public ListNode1 reverseListNode1(ListNode1 head) {
		ListNode1 pre, p, r;
		p = head.next;
		r = p.next;
		p.next = null;
		while (r != null) {
			pre = p;
			p = r;
			r = r.next;
			p.next = pre;
		}
		head.next = p;
		return head;
	}
	/*
	 * 注意java的链表和C++链表的不一样，C++中的链表的头节点为空，JAVA中头节点不为空
	 * 
	 */

	public ListNode1 reverseListNode2(ListNode1 head) {
		ListNode1 cur = head, pre = null;
		ListNode1 rear;
		while (cur != null) {
			rear = cur.next;
			cur.next = pre;
			pre = cur;
			cur = rear;
		}
		return pre;
	}

	/**
	 * 翻转二叉树，将所有二叉树的节点交换（自下而上递归翻转）
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月7日下午4:33:59
	 * @param root
	 * @return
	 */
	public TreeNode reverseTree(TreeNode root) {
		if (root == null) {
			return null;
		}
		TreeNode lNode = reverseTree(root.left);
		TreeNode rNode = reverseTree(root.right);
		root.left = rNode;
		root.right = lNode;
		return root;
	}

	/**
	 * 递归的翻转二叉树，将所有二叉树的节点交换（自上而下反转
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月7日下午4:33:59
	 * @param root
	 * @return
	 */
	public TreeNode reverseTree1(TreeNode root) {
		if (root == null) {
			return null;
		}
		TreeNode temp = root.right;
		root.right = root.left;
		root.left = temp;
		reverseTree1(root.left);
		reverseTree1(root.right);
		return root;
	}

	/**
	 * 判断是否是回文链表
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月7日下午6:31:18
	 * @param head
	 * @return
	 */
	public boolean isPalindrome(ListNode head) {
		ListNode p = head;
		Stack<ListNode> stack = new Stack<>();
		while (p != null) {
			stack.add(p);
			p = p.next;
		}
		while (!stack.isEmpty() && head != null) {
			ListNode pop = stack.pop();
			if (pop.val != head.val) {
				return false;
			}
			head = head.next;
		}
		return true;

	}

	public int lengthOfLongestSubstring(String s) {
		if (s.length() == 0) {
			return 0;
		}
		HashMap<Character, Integer> map = new HashMap<>();
		int max = 0;
		int left = 0;
		for (int i = 0; i < s.length(); i++) {
			if (map.containsKey(s.charAt(i))) {
				left = Math.max(left, map.get(s.charAt(i)) + 1);
				System.out.println(left);
			}
			map.put(s.charAt(i), i);
			max = Math.max(max, i - left + 1);

		}

		return max;

	}

	/**
	 * 盛最多的水（阴影求面积）
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月7日下午7:32:03
	 * @param height
	 * @return
	 */
	public int getMaxFillWater(int[] height) {
		HashMap<Integer, Integer> map = new HashMap<>();
//		for(Integer key : height) {
//			Integer  value = map.get(key);
//			System.out.println(key +","+value);
//		}
		int max = 0;
		for (int i = 0; i < height.length - 1; i++) {
			for (int j = i + 1; j < height.length; j++) {
				max = Math.max((j - i) * Math.min(height[i], height[j]), max);
			}
		}
		return max;
	}

	public int maxArea(int[] height) {
		int l = 0;
		int r = height.length - 1;
		int res = 0, ans = 0;
		while (l < r) {
			res = Math.min(height[l], height[r]) * (r - l);
			ans = Math.max(res, ans);
			if (height[l] <= height[r]) {
				l++;
			} else {
				r--;
			}
		}
		return ans;
	}

	public int search(int[] nums, int target) {
		int low = 0;
		int high = nums.length - 1;
//		int middle;
		while (low <= high) {
			int middle = (low + high) / 2;
			if (nums[middle] == target) {
				return middle;
			}
			if (nums[0] <= nums[middle]) {
				if (nums[0] <= target && target < nums[middle]) {
					high = middle - 1;
				} else {
					low = middle + 1;
				}
			} else {
				if (nums[middle] < target && target <= nums[nums.length - 1]) {
					low = middle + 1;
				} else {
					high = middle - 1;
				}
			}
		}
		return -1;
	}

	public ListNode1 twoAdd(ListNode1 l1, ListNode1 l2) {
		ListNode1 pre = new ListNode1(0);
		ListNode1 cur = pre;
		int carry = 0;
		while (l1 != null || l2 != null) {
			int x = (l1 == null) ? 0 : l1.val;
			int y = (l2 == null) ? 0 : l2.val;
			int sum = x + y + carry;

			carry = sum / 10;
			sum = sum % 10;

			cur.next = new ListNode1(sum);
			cur = cur.next;

			if (l1 != null) {
				l1 = l1.next;
			}
			if (l2 != null) {
				l1 = l2.next;
			}

		}
		if (carry == 1) {
			cur.next = new ListNode1(carry);

		}
		return pre.next;
	}

	/**
	 * 两数相加（有进位操作）
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月7日下午10:47:17
	 * @param l1
	 * @param l2
	 * @return
	 */

	public ListNode addTwoNumbers(ListNode l1, ListNode l2) {
		if (l1 == null)
			return l2;
		if (l2 == null)
			return l1;
		int sum = l1.val + l2.val;
		ListNode head = new ListNode(sum % 10);
		head.next = addTwoNumbers(l1.next, l2.next);
		if (sum > 9)
			head.next = addTwoNumbers(head.next, new ListNode(1));
		return head;

	}

	public double findMedianSortedArrays(int[] nums1, int[] nums2) {
		int[] nums3;
		int m = nums1.length;
		int n = nums2.length;
		nums3 = new int[m + n];
		if (m == 0) {
			if (n % 2 == 0) {
				return (nums2[n / 2 - 1] + nums2[n / 2 + 1] / 2.0);
			} else {
				return nums2[n / 2 + 1];
			}
		}
		if (n == 0) {
			if (m % 2 == 0) {
				return nums1[n / 2 + 1];
			}

		}

		return 0.0;
	}

	/**
	 * leetcode大佬的中心扩散法的方法(某一个当前点左右扩散，如果每个 位置向两边扩散都会出现一个窗口大小（len）。如果
	 * len>maxLen(用来表示最长回文串的长度）。 则更新 maxLen 的值。 因为我们最后要返回的是具体子串，而不是长度，因此，还需要记录一下
	 * maxLen 时的起始位置（maxStart），即此时还要 maxStart=len 本题最容易想到的一种方法应该就是 中心扩散法。
	 * 中心扩散法怎么去找回文串？ 从每一个位置出发 向两边扩散即可。遇到不是回文的时候结束。举个例子，str=acdbbdaastr =
	 * acdbbdaastr=acdbbdaa 我们需要寻找从第一个 b（位置为 333）出发最长回文串为多少。怎么寻找？ 首先往左寻找与当期位置相同的字符，
	 * 直到遇到不相等为止。 然后往右寻找与当期位置相同的字符，直到遇到不相等为止。 最后左右双向扩散，直到左和 右不相等。如下图所示：
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月8日下午7:50:11
	 * @param s
	 * @return
	 */
	public String longestPalindrome(String s) {
		if (s == null || s.length() == 0) {
			return "";
		}
		int left = 0, right = 0;
		int len = 1;
		int maxStart = 0;
		int maxLen = 0;

		for (int i = 0; i < s.length(); i++) {
			left = i - 1;
			right = i + 1;
			while (left >= 0 && s.charAt(left) == s.charAt(i)) {
				len++;
				left--;
			}
			while (right < s.length() && s.charAt(right) == s.charAt(i)) {
				len++;
				right++;
			}
			while (left >= 0 && right < s.length() && s.charAt(left) == s.charAt(right)) {
				len = len + 2;
				left--;
				right++;
			}
			if (len > maxLen) {
				maxLen = len;
				maxStart = left;
			}
			len = 1;
		}
		return s.substring(maxStart + 1, maxStart + maxLen + 1);
	}

	public List<List<Integer>> threeSum(int[] nums) {
		ArrayList<List<Integer>> ans = new ArrayList<>();
		if (nums == null && nums.length < 3) {
			return ans;
		}
		Arrays.sort(nums);
		for (int i = 0; i < nums.length; i++) {
			if (nums[i] > 0) {
				break; // 如果当前数字大于0，则三数之和一定大于0，所以结束循环
			}
			if (i > 0 && nums[i] == nums[i - 1]) {
				continue;
			}
			int L = i + 1;
			int R = nums.length - 1;

			while (L < R) {
				int sum = nums[i] + nums[L] + nums[R];
				if (sum == 0) {
					ans.add(Arrays.asList(nums[i], nums[L], nums[R]));
					while (L < R && nums[L] == nums[L + 1]) {
						L++;
					}
					while (L < R && nums[R] == nums[R - 1]) {
						R--;
					}
					L++;
					R--;
				} else if (sum < 0) {
					L++;
				} else if (sum > 0) {
					R--;
				}
			}
		}
		return ans;

	}

	ArrayList<String> list = new ArrayList<>();
	HashMap<String, String> map = new HashMap<>();

	public List<String> letterCombinations(String digits) {
//		ArrayList<String> list = new ArrayList<>();

		map.put("2", "abc");
		map.put("3", "def");
		map.put("4", "ghi");
		map.put("5", "jkl");
		map.put("6", "mno");
		map.put("7", "pqrs");
		map.put("8", "tuv");
		map.put("9", "wxyz");
//		for (int i = 0; i < digits.length(); i++) {
//			list.add(map.get(digits.charAt(i)));
//			
//		}
		if (digits.length() != 0) {
			BackTrack("", digits);
		}

		return list;

	}

	/**
	 * 电环号码的组合（Java）
	 * @Description
	 * @author zyp
	 * @data 2023年1月8日下午11:17:49
	 * @param already
	 * @param next
	 */

	private void BackTrack(String already, String next) {
		// TODO Auto-generated method stub
		if (next.length()==0) {
			list.add(already);
		}else {
			String key = next.substring(0,1);
			String value = map.get(key);
			for (int i = 0; i < value.length(); i++) {
				String s = already+value.substring(i,i+1);
				BackTrack(s, next.substring(1));
			}
			
		}
		
	}
	/**
	 * 删除倒数第n个节点（快慢指针法）
	 * @Description
	 * @author zyp
	 * @data 2023年1月10日下午3:19:23
	 * @param head
	 * @param n
	 * @return
	 */

	public ListNode1 removeNthFromEnd(ListNode1 head, int n) {
		if (head == null) {
			return null;
		}
		int count = 0;
		ListNode1 pre = new ListNode1(-1);
		pre.next=head;
		ListNode1 fast = pre;
		ListNode1 slow = pre;

		while (count < n) {
			fast = fast.next;
			count++;
		}
		while (fast.next != null) {
			fast = fast.next;
			slow = slow.next;
		}
		slow.next = slow.next.next;
		return pre.next;

	}
	
	public List<String> getnerateParentthesis(int n) {
//		做减法
		List<String> res = new ArrayList<>();
//		特判
		if (n==0) {
			return res;
		}
//		执行深度优先遍历，搜索可能的结果
		dfs("",n,n,res);
		return res;
	}
	
	/**
	 * 
	 * @Description
	 * @author zyp
	 * @data 2023年1月10日下午3:44:18
	 * @param curStr   当前递归得到的结果
	 * @param left    左括号还有几个可以使用
	 * @param right   右括号还有几个可以使用
	 * @param res   结果集
	 */
	private void dfs(String curStr, int left, int right, List<String> res) {
		// TODO Auto-generated method stub
//		因为每一次的尝试，都可以使用新的字符串变量，所以无需回顾
//		在递归终止的时候，直接把它添加到结果集即可，注意
		if (left==0 && right==0) {
			res.add(curStr);
			return;
		}
		
//		剪枝（左括号可以使用的个数严格大于右括号可以使用的个数，才剪枝，注意这个细节）
		if (left>right) {
			return;
		}
		if (left>0) {
			dfs(curStr+'(', left-1, right, res);
		}
		if (right>0) {
			dfs(curStr+')', left, right-1, res);
		}
	}
	/**
	 * 合并K个链表
	 * @Description
	 * @author zyp
	 * @data 2023年1月10日下午4:42:02
	 * @param lists
	 * @return
	 */
	
	
	public ListNode1 mergeKLists(ListNode1[] lists) {
		ListNode1 head=new ListNode1(0);
		ListNode1 tail=head;
		if (lists==null) {
			return null;
		}
		while (true) {
			ListNode1 minNode =null;
			int minPointer=-1;
			for (int i = 0; i < lists.length; i++) {
				if(lists[i]==null) {
					continue;
				}
				if (minNode==null || lists[i].val < minNode.val) {
					minNode = lists[i];
					minPointer=i;
				}
			}
			if(minPointer == -1) {
				break;
			}
			tail.next = minNode;
			tail=tail.next;
			lists[minPointer]=lists[minPointer].next;
		}
		return head.next;
	}
	/**
	 * 整数数组的 下一个排列 是指其整数的下一个字典序更大的排列。更正式地，
	 * 如果数组的所有排列根据其字典顺序从小到大排列在一个容器中，那么数组的 
	 * 下一个排列 就是在这个有序容器中排在它后面的那个排列。如果不存在下一个
	 * 更大的排列，那么这个数组必须重排为字典序最小的排列（即，其元素按升序排列）。
	 * @Description
	 * @author zyp
	 * @data 2023年1月10日下午5:38:10
	 * @param nums
	 */
	
	public void nextPermulation(int[] nums) {
		int i=nums.length-2;
		while(i>=0 && nums[i]>=nums[i+1]) {
			i--;
		}
		if (i>=0) {
			int j = nums.length-1;
			while (j>=0 && nums[i]>=nums[j]) {
				j--;
			}
			swap(nums,i,j);
		}
		reverse(nums,i+1);
		
		
	}

	private void reverse(int[] nums, int start) {
		// TODO Auto-generated method stub
		int left=start,right = nums.length-1;
		while(left<right) {
			swap(nums, left, right);
			left++;
			right--;
		}
		
	}

	private void swap(int[] nums, int i, int j) {
		// TODO Auto-generated method stub
		int temp = nums[i];
		nums[i]=nums[j];
		nums[j]=temp;
	}
	
	public int maxProfit(int[] prices,int k) {
		if(prices.length == 0){
            return 0;
        }
        k=Math.min(k,prices.length/2);
        int[] buy=new int[k+1];
        int[] sell=new int[k+1];
        // 初始化初值
        buy[0]=-prices[0];
        sell[0]=0;
        // 初始化
        for(int i=1;i<=k;++i){
            buy[i]=sell[i]=Integer.MIN_VALUE/2;
        }
        for (int i = 1; i < prices.length; ++i) {
            buy[0] = Math.max(buy[0], sell[0] - prices[i]);
            for (int j = 1; j <= k; ++j) {
                buy[j] = Math.max(buy[j], sell[j] - prices[i]);
                sell[j] = Math.max(sell[j], buy[j - 1] + prices[i]);  
            }
        }
        //返回最后一个
        return Arrays.stream(sell).max().getAsInt();
		
	}
	
	public int removeDuplicates(int[] nums) {
		int n=nums.length;
		int k=0;
		for (int i = 0; i < n-1; i++) {
			if (nums[i]==nums[i+1]) {
				for(int j=i+1;j<n-1;j++) {
					nums[j]=nums[j+1];
					
				}
				n--;
			}else {
				k++;
			}
		}
		
		return n;
	}
	
	public int removeDuplicates1(int[] nums) {
		int n=nums.length;
		if (n==0) {
			return 0;
		}
		int slow=0,fast=0;
		while (fast < n) {
			if (nums[slow]!=nums[fast]) {
				slow++;
				nums[slow]=nums[fast];
			}
			fast++;
		}
//		数组长度的索引+1;
		return slow+1;
	}
	
	
	
	
	
 
}
