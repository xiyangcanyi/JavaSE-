package com.atguigu.exer1;

public class Circle extends GeometricObject{

	private double radius;
	public Circle(double radius, String color, double weight) {
		super(color, weight);
		// TODO Auto-generated constructor stub
		this.radius=radius;
	}
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	
	@Override
	public double findArea() {
		// TODO Auto-generated method stub
		return 3.14*radius*radius;
	}
	
}
