package com.atguigu.java;

public class Woman extends Person {
	boolean isBeauty;
	public void goShopping() {
		System.out.println("女人喜欢购物");
	}
	
	public void eat() {
		System.out.println("女人少吃，为了减肥");
	}
	public void walk() {
		System.out.println("女人窈窕走路");
	}
}
