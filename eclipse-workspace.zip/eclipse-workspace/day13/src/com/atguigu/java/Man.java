package com.atguigu.java;


public class Man extends Person {
	boolean isSmoking;
	
	public void earnMoney() {
		System.out.println("男人负责挣钱养家");
	}
	@Override
	public void eat() {
		System.out.println("男人多吃肉，多张肌肉");
	}
	public void walk() {
		System.out.println("走路要霸气");
	}
	
}
