package com.atguigu.java;

public class Person {
	String name;
	int age;
	
	public void eat() {
		System.out.println("人，吃饭");
	}
	public void walk() {
		System.out.println("人，走路");
	}
}
