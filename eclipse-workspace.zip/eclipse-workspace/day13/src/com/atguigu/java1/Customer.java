package com.atguigu.java1;

import java.util.Objects;

public class Customer {
	String name;
	int age;
	
	public Customer(String name,int age) {
		super();
		this.name=name;
		this.age=age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	//重写原则：比较两个对象的”实体内容是否相同“
//	手动实现equals（）重写
//	public boolean equals(Object obj) {
//		// TODO Auto-generated method stub
//		if (this==obj) {
//			return true;
//		}
//		if (obj instanceof Customer) {
//			Customer cust=(Customer)obj;
////			比较两个对象的每个属性是否相同
////			if (this.age==cust.age && this.name.equals(cust.name)) {
////				return true;
////			}else {
////				return false;
////			}
////			或
//			return this.age==cust.age && this.name.equals(cust.name);
//			
//		}
//		return false;
//	}

//	自动重写equals（）
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return age == other.age && Objects.equals(name, other.name);
	}
//	@Override
//	手动实现（重写的）
//	public String toString() {
//		return "Customer[name ="+name+",age = "+age+"]";
//	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", age=" + age + "]";
	}
	
	
}
