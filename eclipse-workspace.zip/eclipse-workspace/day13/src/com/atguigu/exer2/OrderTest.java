package com.atguigu.exer2;

import java.util.Objects;

public class OrderTest {
	public static void main(String[] args) {
		Order o1=new Order(1001, "AA");
		Order o2=new Order(1001, "BB");
		
		System.out.println(o1.equals(o2));//false
		Order o3=new Order(1001, "BB");
		System.out.println(o2.equals(o3));//true
//		字符串常量池的复用技术
		String s1="BB";
		String s2="BB";
		System.out.println(s1==s2);
		
	}
}
class Order{
	private int orderId;
	private String orderName;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getOrderName() {
		return orderName;
	}
	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}
	public Order(int orderId, String orderName) {
		super();
		this.orderId = orderId;
		this.orderName = orderName;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		return orderId == other.orderId && Objects.equals(orderName, other.orderName);
	}
	
	
}
