package com.atguigu.java;
/*
 * 一、数组的概述
 * 1.数组的理解，十多个相同类型的数据按一定的顺序排列的集合，并使用一个名字命名
 * 并通过编号的方式对这些数据进行统一的管理
 * 
 * 2.数组相关概念
 * 数组名
 * 下标
 * 元素
 * 角标、下标、索引
 * 数组的长度：元素的个数
 * 3.数组的特点：
 * 1） 数组是有序排列
 * 2） 数组属于引用数据类型变量，但是数组的元素有之前的基本数据类型、引用数据类型的元素（即对象数组）
 * 3）创建数组对象会在内存中开辟一整块连续的空间
 * 4）数组的长度一旦确定，就不能修改
 * 
 * 4.数组的分类：
 * 1）一维数组、二维数组.....
 * 2)按照数组元素的类型：基本数据类型元素的数组、引用数据类型元素的数组 
 * 
 * 5.数组的使用
 * 1）一维数组的声明与初始化
 * 2）如何调用数组指定位置的元素
 * 3）如何获取数组的长度
 * 4）如何遍历数组
 * 5）数组元素的默认初始化值 见ArrayTest1.java
 * 6）数组的内存解析
 * 
 */

public class ArrayTest {
	/**
	 * @Description
	 * @author zyp
	 * @data 2022年12月4日下午8:48:17
	 * @param args
	 */
	/**
	 * @Description
	 * @author zyp
	 * @data 2022年12月4日下午8:48:27
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		//1）一维数组的声明与初始化
		int num;//声明
		num=10;//初始化
		int id=1001;//声明+初始化
		int[] ids;//声明
		//1.1静态初始化：数组的初始化和数组元素的赋值操作同时进行		
		ids=new int[] {1001,1002,1003,1004};
//		1.2.动态初始化和数组元素的赋值操作分开进行
		String[] names=new String[5];
		
		
//		2）如何调用数组指定位置的元素
//		数组的下标从0开始，到长度-1
		names[0]="wangming";
		names[1]="wanghe";
		names[2]="zhangxueliang";
		names[3]="zhangjuju";//charAt(0)
		names[4]="zhouyang";
		
//		3）如何获取数组的长度:属性：length
		System.out.println(names.length);
		System.out.println(ids.length);
//		* 4）如何遍历数组
		for(int i=0;i<names.length;i++) {
			System.out.println(names[i]);
		}
		//5）数组元素的默认初始化值
		
		
//		System.out.println();
		
		
		
		
		
	}

}
