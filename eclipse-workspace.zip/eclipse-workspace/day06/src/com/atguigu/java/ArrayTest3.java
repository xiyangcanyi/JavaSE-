package com.atguigu.java;
/*
 * 规定：二维数组分为外层数组的元素，内层数组的元素
 * int[] arr[]= new int[4][3];//int[][] arr=
 * 外层元素：arr[0],arr[1]等
 * 内层元素：arr[0][0],arr[1][2]等
 * 5）数组元素的默认初始化值 见ArrayTest3.java
 * 针对于初始化一：比如int[][] arr=new int[4][3];
 * 外层元素的初始化值：地址值
 * 内层元素的初始化值：与一维数组初始化情况相同
 * 
 *  针对于初始化二：比如int[][] arr=new int[4][];
 * 外层元素的初始化值：null
 * 内层元素的初始化值：与一维数组初始化情况相同
 * 6）数组的内存解析：不能调用，否则报错
 */
public class ArrayTest3 {
	public static void main(String[] args) {
		int[][] arr=new int[4][3];
		System.out.println(arr[0]); //[I@3d012ddd   16进制的地址值
		System.out.println(arr[0][0]);//0
		System.out.println(arr);  //[[I@626b2d4a  [[表示二维数组，I表示为整型
		
		System.out.println("---------------");
		float[][] arr1=new float[4][3];
		System.out.println(arr1[0]); //[F@5e91993f
		System.out.println(arr1[0][0]);//0.0
		System.out.println(arr1);  //[[F@1175e2db
		
		System.out.println("---------------");
		String[][] arr2=new String[4][3];
		System.out.println(arr2[0]); 
		System.out.println(arr2[0][0]);
		System.out.println("---------------");
		double[][] arr3=new double[4][];
		System.out.println(arr3[1]); 
		System.out.println(arr3[1][0]);//报错空指针异常
		
		
		
	}

}
