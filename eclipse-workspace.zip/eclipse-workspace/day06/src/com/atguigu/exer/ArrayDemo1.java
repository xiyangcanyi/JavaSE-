package com.atguigu.exer;

import java.util.Scanner;

public class ArrayDemo1 {
	public static void main(String[] args) {
		//1.使用Scanner，读取学生个数
		Scanner scanner=new Scanner(System.in);
		System.out.println("请输入学生人数：");
		int num=scanner.nextInt();
		int[] score=new int[num];
		int max=score[0];
		System.out.println("请输入"+num+"个学生成绩");
		for(int i=0;i<score.length;i++) {
			score[i]=scanner.nextInt();
			if(score[i]>max) {
				max=score[i];
			}
		}
		//获取最大值：最高分
//		int max=score[0];
//		for(int i=0;i<score.length;i++) {
//			if(score[i]>max) {
//				max=score[i];
//			}
//		}
		char level;
		for(int i=0;i<score.length;i++) {
			if(max-score[i]<=10) {
				level='A';
			}
			else if (max-score[i]<=20) {
				level='B';
			}else if (max-score[i]<=30) {
				level='C';
			}else {
				level='D';
			}
			System.out.println("student "+i+" score is "+score[i]+",grade is "+level);
		}
		
	}

}
