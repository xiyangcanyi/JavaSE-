package com.atguigu.java1;
/*
 * JavaBean是一种Java语言写成可重用组件
 * 
 * 所谓JavaBean，是指符合如下标准的Java类
 * 	>类是公共的
 * 
 * 	>有一个无参的公共的构造器
 * 
 * 	>有属性，且有对印的get、set方法
 * 
 * +表示public类型，-表示private类型，#表示protected
 * 
 * 
 * 
 */
public class Customer {
	private int id;
	private String name;
	public Customer() {
		
	}
	public void setName(String n) {
		name=n;
	}
	public String getName() {
		return name;
	}
	public void setId(int Id) {
		id=Id;
	}
	public int getId() {
		return id;
	}
	
	
}
