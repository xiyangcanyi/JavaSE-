package com.atguigu.exer1;
/*
 * 编写两个类：triAngle和测试类，其中第一个中声明私有的底边长base和高height，同时声明公告饭囊发访问私有变量
 * 此外，提供类的必要的构造器。零一个类中使用这些公共方法，计算三角形面积
 * 
 * 
 * 
 * 
 */
public class TriAngle {//angle:角，angel：天使
	private double base;
	private double height;
	
//	构造器
	public TriAngle() {
		
	}
	
	public TriAngle(double b,double h) {
		base=b;
		height=h;
	}
	
	public void setBase(double b) {
		base=b;
	}
	public double getBase() {
		return base;
	}
	public void setHeight(double h) {
		height=h;
	}
	public double getHeight() {
		return height;
	}

}
