package com.atguigu.java;
/*
 * 面向对象得特征一：封装与隐藏  3W:what? why? how?
 * 一、问题的引入：
 * 当我们创建一个类的对象时，我们可以通过“对象。属性”的方式，对对象的属性进行赋值时，这里的赋值操作受到属性的数据类型和存储
 * 范围的制约。除此之外，没有其他制约条件。但是，在实际问题中，我们往往需要给属性赋值时加入额外的限制条件。这个条件不能再属性
 * 声明时体现，我们只能通过方法的进行限制条件的添加（比如：set，get）
 * 同时，我们需要避免用户在使用“对象。属性”的方式对属性进行赋值，则我们蒋属性声明成私有的（private）
 * ---》此时，针对于属性就体现了封装性
 * 
 * 二、封装性体现
 * 我们将类的属性xxx私有化（private），同时，提供（public）方法来获取（getXxx）和设置（setXxx）此属性的值
 * 
 * 拓展：封装性体现，1.如上  2.不对外暴露的私有方法 3.单例模式
 * 
 * 三、封装性的体现，需要权限修饰符来配合。
 * 
 * 1.Java规定4种权限（从小到排列）：private、缺省、protected、public
 * 2.4种权限可以使用修饰及类的的内部结构：属性、方法、构造器、内部类
 * 		修饰类：只能使用：缺省、public
 * 
 * java提供了4种权限修饰符及类的内部结构，体现类及类的内部结构在被调用时的可见性的大小
 * 
 * 
 */
public class AnmalTest {
	public static void main(String[] args) {
		Animal a=new Animal();
		a.name="大黄";
//		a.age=1;
		a.getAge();
		a.setAge(1);
		a.setLegs(4);;
		a.show();
//		a.legs=-4;//The field Animal.legs is not visible
		a.setLegs(-4);
		a.show();
	}
}
class Animal{
	String name;
	private int age;
	private int legs;
	public void setLegs(int l) {
		if(l>=0 && l%2==0) {
			legs=l;
		}else {
			legs=0;
//			抛出一个异常（后面讲）
		}
	}
	public void setAge(int a) {
		age=a;
	}
	public int getAge() {
		return age;
	}
	
	public int getLegs() {
		return legs;
	}
		
	
	public void eat() {
		System.out.println();
	}
	public void show() {
		System.out.println("name: "+name+",age: "+age+",legs: "+legs);
	}
}
