package com.atguigu.java;
/*
 * 算法得考查：数组的复制、反转、查找（线性查找、二分查找）
 */
public class ArrayTest2 {
	public static void main(String[] args) {
		String[] arr=new String[] {"JJ","DD","MM","GG","AA","BB"};
		
		String[] arr1=new String[arr.length];
//		数组得复制
		for (int i = 0; i < arr1.length; i++) {
			arr1[i]=arr[i];
		}
		
//		反转
//		方法一：一个指针
//		for (int i = 0; i < arr.length/2; i++) {
//			String temp=arr[i];
//			arr[i]=arr[arr.length-i-1];
//			arr[arr.length-1-i]=temp;
//		}
//		方法二：两指针
		for (int i = 0,j=arr.length-1; i < j; i++,j--) {
			String temp=arr[i];
			arr[i]=arr[j];
			arr[j]=temp;
		}
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+"\t");
		}
		System.out.println();
//		线性查找：
		String dest="BB";
		boolean isFlag=true;
		for (int i = 0; i < arr.length; i++) {
			if(dest.equals(arr[i])) {
				isFlag=false;
				System.out.println("找到了，位置是: "+i);
			}
		}
		if (isFlag) {
			System.out.println("没找到");
		}
//		二分查找
//		前提：所要查找的数组必须有序
		int[] arr2=new int[] {-98,-34,2,34,54,66,79,105,210,333};
		int dest1=78;
		boolean isFlag1=true;
		int head=0;
		int end=arr2.length-1;
		while (head<=end) {
			int middle=(head+end)/2;
			if(dest1==arr2[middle]) {
				System.out.println("找到了位置为："+middle);
				isFlag1=false;
				break;
			}else if(dest1>arr2[middle]) {
				head=middle+1;
			}else {
				end=middle-1;
			}
			
		}
		if(isFlag1) {
			System.out.println("没找到抱歉！");
		}
		
	}

}
