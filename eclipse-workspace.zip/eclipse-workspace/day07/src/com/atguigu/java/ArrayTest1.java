package com.atguigu.java;
//求所有数组元素的最大值、最小值、总和、平均值，并输出
public class ArrayTest1 {
	public static void main(String[] args) {
		int[] arr=new int[10];
		for (int i = 0; i < arr.length; i++) {
			arr[i]=(int)(Math.random()*(99-10+1)+10);
			
		}
//		遍历
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		int maxValue=arr[0];
		int sum=0;
		double avgValue;
		for (int i = 0; i < arr.length; i++) {
			if(maxValue<arr[i]) {
				maxValue=arr[i];
			}
			sum+=arr[i];
		}
		avgValue=sum/arr.length;
		System.out.println(maxValue);
		System.out.println(sum);
		System.out.println(avgValue);
		
	}

}
