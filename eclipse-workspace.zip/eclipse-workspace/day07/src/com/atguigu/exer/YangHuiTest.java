package com.atguigu.exer;
/*
 * 打印杨辉三角
 */
public class YangHuiTest {
	public static void main(String[] args) {
		//1.声明初始化:二维数组
		int[][] arr=new int[10][];
//		2.给数组赋值
		for (int i = 0; i < arr.length; i++) {
			arr[i]=new int[i+1];
			
			//2.1 给首末赋值
			arr[i][0]=1;
			arr[i][i]=1;
			for (int j = 1; j < arr[i].length-1; j++) {
				arr[i][j]=arr[i-1][j-1]+arr[i-1][j];
			}
			
		}
//		3.遍历数组
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}

}
