package com.atguigu.java;


/*
 * 类中的方法的声明和使用
 * 
 * 方法：描述类中应该具有的功能
 * 
 * 比如：Math类：sqrt()\random()\...
 * 		Scanner类：next XXX（）
 * Arrays类:sort()\binarySearch()\toString()\eaulas
 * 2.方法的声明：权限修饰符，返回值类型、方法名（形参列表）{
 * 		方法体
 * }
 * 注意：static、final、abstract、来修饰的方法，后面讲
 * 
 *3.说明3.1关于权限修饰符
 *		关于权限修饰符：默认方法的权限修饰符都先使用public
 *		java的规定是4种权限：private、public、缺省、protected 
 * 	3.2 返回值类型 有返回值vs没有返回值
 * 		3.2.1如果方法有返回值，则必须在方法声明时，指定返回值类型，同时，方法中，需要使用return关键字
 * 		来返回指定类型的变量或常量
 * 		如果方法没有返回值，则方法声明时使用void来表示，通常没有返回值的方法种，就不使用return。但是，如果使用的话，
 * 		只能时return；表示结束此方法
 * 		3.2.2. 需不需要返回值：
 * 			1.题目要求
 * 			2.凭经验
 * 	3.3 方法名：属于标识符，遵循标识符的规则的规则和规范，见名知意
 * 
 * 	3.4 形参列表：方法可以声明0个1个或者多个形参
 * 		3.4.1 格式：数据类型1 形参1，数据类型2 形参2，...
 * 		3.4.2 我们定义方法：该不该定义形参？
 * 			题目要求
 * 			凭经验，具体问题具体分析
 * 3.5.方法体：方法功能的体现。
 * 
 * 	return关键字使用：
 * 1.使用范围：使用在方法体中
 * 2.作用：结束一个方法
 * 针对于有返回值类型的方法，使用return 数据 方法返回所要的数据
 * 
 * 3.注意点：return关键字后面不可以有执行语句
 * 
 */
public class CustomersTest {
	public static void main(String[] args) {
		Customer customer=new Customer();
		customer.eat();
		customer.sleep(8);
	}
}
class Customer{
//	属性
	String name;
	int age;
	boolean isMale;
//	方法：
	public void eat() {
		System.out.println("客户吃饭");
	
		return;
	}
	public void sleep(int hour) {
		System.out.println("休息了"+hour+"个小时");
		eat();
	}
	public String getName() {
		return name;
	}
	public String getNation(String nation) {
		String info="我的国际是："+nation;
//		System.out.println("我来自"+nation);
		return info;
	}
	
}
