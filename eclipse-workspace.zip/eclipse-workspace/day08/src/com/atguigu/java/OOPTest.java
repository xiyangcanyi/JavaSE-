package com.atguigu.java;
/*
 * 一、Java面向对象学习的三条主线（第4-6章）
 * 1.java类及类的成员：属性、方法、构造器；代码块，内部类
 * 2.面向对象三大特征：封装、继承、多态、（抽象性）
 * 3.其他关键字：this、super、static、final、abstract、interface、package、import
 * 
 * 
 * 面向对象的两个要素：
 * 类：对一类事物的抽象的概念上的定义
 * 对象：是实际存在的每个个体，也称为实例
 */
public class OOPTest {
	
}

