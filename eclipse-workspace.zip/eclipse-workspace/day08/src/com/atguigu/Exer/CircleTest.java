package com.atguigu.Exer;

public class CircleTest {
	public static void main(String[] args) {
		Circle circle=new Circle();
		circle.radius=2.1;
		double area=circle.findaArea();
		System.out.println(area);
	}
}
//圆
class Circle{
//	属性
	double radius;
	//求圆的面积
	public double findaArea() {
		double area=Math.PI*radius*radius;
		return area;
	}
}