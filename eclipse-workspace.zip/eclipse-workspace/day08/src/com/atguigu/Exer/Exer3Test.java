package com.atguigu.Exer;

public class Exer3Test {
	public static void main(String[] args) {
		Exer3Test exer3Test=new Exer3Test();
		int area=exer3Test.method();
		System.out.println("面积为："+area);
	}
//	3.1
//	public void method() {
//		for (int i = 0; i < 10; i++) {
//			for (int j = 0; j < 8; j++) {
//				System.out.print("* ");
//			}
//			System.out.println();
//		}
//	}
//	3.2
	public int method() {
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 8; j++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		return 10*8;
	}
	
}
