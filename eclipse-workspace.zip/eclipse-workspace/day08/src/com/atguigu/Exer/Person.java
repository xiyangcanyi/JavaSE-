package com.atguigu.Exer;

public class Person {
	String name;
	int age;
	/**
	 * sex为0是男，为1是表示女
	 * 
	 */
	int sex;
	
	public void study() {
		System.out.println("studying");
	}
	public void showAge() {
		System.out.println("age: "+ age);
	}
	public int addAge(int i) {
		age +=i;
		return age;
		
	}
}
