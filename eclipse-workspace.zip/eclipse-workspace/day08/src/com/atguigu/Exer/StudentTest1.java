package com.atguigu.Exer;
/*
 * 此代码是对StudentTest.java的改进，讲操作数组的功能在方法中,简洁，提高代码的复用性
 */
public class StudentTest1 {
	public static void main(String[] args) {
//		声明Student类型数组
		Student1[] students=new Student1[20];
		for (int i = 0; i < students.length; i++) {
//			给数组元素赋值
			students[i]=new Student1();
//			给Student对象的属性赋值
			students[i].number=(i+1);
//			年纪：[1,6]
			students[i].state=(int)(Math.random()*(6-1+1)+1);
//			成绩[0,100]
			students[i].score=(int)(Math.random()*(100-0+1));
		}
		StudentTest1 test1=new StudentTest1();
		test1.print(students);
		System.out.println("-----------------------");
		test1.searchState(students, 3);
		System.out.println("-----------------------");
		test1.sort(students);
		test1.print(students);
//		打印学生信息
//		for (int i = 0; i < students.length; i++) {
//			//System.out.println(students[i].number+","+students[i].state+","+students[i].score);
////			students[i].info();
//			System.out.println(students[i].info());
//		}
//		输出3年级学生信息
//		System.out.println("**************************");
//		for (int i = 0; i < students.length; i++) {
//			if(students[i].state==3) {
//				System.out.println(students[i].info());
//			}
//		}
//		使用冒泡排序按学生成绩排序，并遍历输出学生信息
//		System.out.println("**************************");
//		for (int i = 0; i < students.length-1; i++) {
//			for (int j = 0; j < students.length-1-i; j++) {
//				if(students[j].score>students[j+1].score) {
//					Student1 temp=students[j];
//					students[j]=students[j+1];
//					students[j+1]=temp;
//				}
//			}
//		}
//		for (int i = 0; i < students.length; i++) {
//			System.out.println(students[i].info());
//		}
		
	}
	/**
	 * 
	 * @Description 遍历数组
	 * @author zyp
	 * @data 2022年12月10日下午4:49:48
	 * @param students
	 */
//	遍历Student1[]数组操作
	public void print(Student1[] students) {
		for (int i = 0; i < students.length; i++) {
			//System.out.println(students[i].number+","+students[i].state+","+students[i].score);
//			students[i].info();
			System.out.println(students[i].info());
		}
	}
	/**
	 * 
	 * @Description 查找Student数组中指定年级学生信息
	 * @author zyp
	 * @data 2022年12月10日下午4:38:59
	 * @param students
	 * @param state
	 */
	public void searchState(Student1[] students,int state) {
		for (int i = 0; i < students.length; i++) {
			if(students[i].state==3) {
				System.out.println(students[i].info());
			}
		}
	}
	/**
	 * 
	 * @Description 使用冒泡排序按学生成绩排序，并遍历输出学生信息
	 * @author zyp
	 * @data 2022年12月10日下午4:49:17
	 * @param students
	 */
	public void sort(Student1[] students) {
		System.out.println("**************************");
		for (int i = 0; i < students.length-1; i++) {
			for (int j = 0; j < students.length-1-i; j++) {
				if(students[j].score>students[j+1].score) {
					Student1 temp=students[j];
					students[j]=students[j+1];
					students[j+1]=temp;
				}
			}
		}
	}
	
	

}
class Student1{
	int number;//学号
	int score;//成绩
	int state;//年级
	
	public String info() {
//		System.out.println("学号"+number+","+"年级："+state+","+"成绩："+score);
		return "学号"+number+","+"年级："+state+","+"成绩："+score;
	}
}