package com.atguigu.java1;

import org.junit.Test;

public class Student extends Person{
	String major;

	
	public Student() {

	}


	public Student(String major) {
	
		this.major = major;
	}
	@Test
	public void study() {
		System.out.println("学习，专业是"+major);
	}
//	对父类的方法进行重写
	public void eat() {
		System.out.println("学生应该吃有营养的食物");
	}
	@Override
	public void walk(int distance) {
		// TODO Auto-generated method stub
		super.walk(distance);
	}
	
	
}
