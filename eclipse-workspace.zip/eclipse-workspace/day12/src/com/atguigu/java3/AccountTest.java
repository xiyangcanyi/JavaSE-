package com.atguigu.java3;
/*
 * 创建Account类子类checkAccount代表可透支的账户，该账户定义一个属性overdraft代表可透支限额。
 * 在CheckAccount类中重写
 * 
 * 
 * 
 */
import com.atguigu.exer2.Account;

public class AccountTest {
	public static void main(String[] args) {
		Account acct=new Account(1122, 20000, 0.045);
		acct.withdraw(30000);
		
		System.out.println("你的账户余额为"+acct.getBalance());
		
		acct.withdraw(2500);
		System.out.println("你的账户余额为"+acct.getBalance());
		acct.deposit(3000);
		System.out.println("你的账户余额为"+acct.getBalance());
		
		System.out.println("月利率为"+(acct.getMonthlyInterest()*100)+"%");
	}
}
