package com.atguigu.java4;

public class Person {
	String name;
	int age;
	
	public void eat() {
		System.out.println("人，吃饭");
	}
	public void walk() {
		System.out.println("人，走路");
	}
}
