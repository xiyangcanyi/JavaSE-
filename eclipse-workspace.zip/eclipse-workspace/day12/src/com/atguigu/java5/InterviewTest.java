package com.atguigu.java5;
import java.util.Random;

//面试题：多态是编译时行为还是运行时行为？ 运行时行为 
//证明如下：
//调用方法时，编译时看左边，运行时看右边。

//区分方法的重写和重载？
//答：
//①：二者的概念：
//②：重载和重写的具体规则
//③：重载：不表现为多态性
/*重写：表现为多态性
 * 
 * 
 * 
 * 
 * 
 */



class Animal  {
	protected void eat() {
		System.out.println("animal eat food");
	}
}

class Cat  extends Animal  {
 
	protected void eat() {
		System.out.println("cat eat fish");
	}
}

class Dog  extends Animal  {
 
	public void eat() {
		System.out.println("Dog eat bone");

	}

}

class Sheep  extends Animal  {
 

	public void eat() {
		System.out.println("Sheep eat grass");

	}

 
}

public class InterviewTest {

	public static Animal  getInstance(int key) {
		switch (key) {
		case 0:
			return new Cat ();
		case 1:
			return new Dog ();
		default:
			return new Sheep ();
		}

	}

	public static void main(String[] args) {
		int key = new Random().nextInt(3);

		System.out.println(key);

		Animal  animal = getInstance(key);
		
		animal.eat();
		 
	}

}
