package com.atguigu.exer;

public class Kids extends ManKind{
	private int yearOld;
	
	public Kids(int yearOld) {
	
		this.yearOld = yearOld;
	}

	public Kids() {
		
	}

	public int getYearOld() {
		return yearOld;
	}

	public void setYearOld(int yearOld) {
		this.yearOld = yearOld;
	}

	public void printAge() {
		System.out.println("I am: "+yearOld+" years old.");
	}
	@Override
	public void employeed() {
		// TODO Auto-generated method stub
		System.out.println("kids should study and no job");
	}
}
