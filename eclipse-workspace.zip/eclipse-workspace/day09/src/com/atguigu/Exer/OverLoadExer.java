package com.atguigu.Exer;
/*
 * 方法重载的联系
 */
public class OverLoadExer {
//	如下三个方法构成重载
	public void mOL(int i) {
		System.out.println(i*i);
	}
	public void mOL(int i,int j) {
		System.out.println(i*j);
	}
	public void mOL(String s) {
		System.out.println(s);
	}
//	如下三个方法构成重载
	public int max(int i,int j) {
		return (i>j)? i : j;
	}
	public double max(double i,double j) {
		return (i>j)? i : j;
	}
	public double max(double i,double j,double k) {
		return ((i>j)? i : j)>k? ((i>j)? i : j):k;
	}
	
}
