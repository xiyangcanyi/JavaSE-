package com.atguigu.java1;
/*
 * 方法的形参的传递机制：值传递
 * 
 * 1.形参：方法定义时，生命在小括号内的参数
 * 		实参：方法调用时，实际传递给形参的数据
 * 
 * 2.值传递机制
 * 如果变量是基本数据类型，此时实参赋给形参的是实参的真是存储的数据值
 * 
 * 
 * 
 */
public class ValueTransferTest1 {
	public static void main(String[] args) {
		int m=10;
		int n=20;
		System.out.println("m=" + m+",n="+n);
//		交换两个变量的值操作
//		int temp=m;
//		m=n;
//		n=temp;
//		创建对象并且实例化
		ValueTransferTest1 test1=new ValueTransferTest1();
		test1.swap(m, n);//m,n为实参
		System.out.println("m="+ m+",n="+n);
//		System.out.println("********************");
	}
	public void swap(int a,int b) {//a,b为形参
		int temp=a;
		a=b;
		b=temp;	
		System.out.println("m="+ a+",n="+b);
	}

}
