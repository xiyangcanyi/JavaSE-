package com.atguigu.java1;
/*
 * 可变个数形参的方法：
 * 1.jdk 5.0新增的内容
 * 
 * 2.
 * 2.1具体使用：数据类型 ... 变量名
 * 2.2当调用可变个数形参的方法时，传入参数可以是：0个，1个。。。多个
 * 2.3可变个数的方法与本类中的方法名相同，形参不同的方法之间构成了重载
 * 2.4可变个数的方法与本类中的方法名相同，形参类型也相同的数组不构成重载
 * 2.5可变个数的形参在方法的形参中， 必须声明在末尾
 * 2.6可变形参在方的形参中，最多只能声明一个可变形参
 */
public class MethodArgsTest {
	public static void main(String[] args) {
		MethodArgsTest test=new MethodArgsTest();
		test.show(12);
		test.show("122","world");
		test.show();
	}
	public void show(int i) {
		
	}
//	public void show(String s) {
//		System.out.println("show(String)");
//	}
	public void show(String ... strs) {//可变参数个数
		System.out.println("shouw(String ... strs)");
	}
//	public void show(String[] strs) {
//		
//	}
}
