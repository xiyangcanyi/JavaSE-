package com.atguigu.java1;
/*
 * 
 */
public class ArrayPrintTest {
	public static void main(String[] args) {
		int[] arr=new int[] {1,2,3};
		System.out.println(arr);//地址值
		
		char[] arr1=new char[] {'a','b','c'};
		System.out.println(arr1);//abc
	}

}
