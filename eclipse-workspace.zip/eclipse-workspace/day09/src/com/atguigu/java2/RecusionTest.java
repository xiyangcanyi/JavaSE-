package com.atguigu.java2;
/*
 * 递归方法的使用（了解）
 * 1.递归方法：一个方法体内调用了自身
 * 2。方法递归包含了一种隐式的循环，他会重复执行某段代码，但这种重复执行无需循环控制
 * 递归一定要有向已知方向递归，否则变成了无穷递归，类似于死循环
 */
public class RecusionTest {
	public static void main(String[] args) {
		
	
//	例一：计算1~100之间的所有自然数的和
//		方式一：循环实现
	int sum=0;
	for (int i = 0; i < 100; i++) {
		sum+=i;
	}
	RecusionTest test=new RecusionTest();
	int sum1=test.getSum(100);
	System.out.println("总和为："+sum1);
	int value=test.f(10);
	System.out.println(value);
	
}
//	方式二，递归实现
	public int getSum(int n) {
		if(n==1) {
			return 1;
		}else {
			return n+getSum(n-1);
		}
		
	}
//	计算1~n之间的所有自然数的乘积：n！
	public int getSum1(int n) {
		if(n==1) {
			return 1;
		}else {
			return n*getSum1(n-1);
		}
		
	}
	
//	例3.已知一个数列f（0）=1，
	public int f(int n) {
		if(n==0) {
			return 1;
		}else if(n==1) {
			return 4;
		}else {
			return 2*f(n-1)+f(n-2);
		}
	}
//	例四：斐波拉契数列，规律：一个数等于前两个数之和

	
//	例五：汉诺塔问题：
	
//	例6 快排

}
