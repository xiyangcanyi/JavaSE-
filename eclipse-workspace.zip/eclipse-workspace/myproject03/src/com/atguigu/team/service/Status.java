package com.atguigu.team.service;

/**
 * 
 * @Description 表示员工的状态
 * @author zyp Email:1521165790@qq.com
 * @version
 * @data 2023年1月22日下午7:56:54
 */
public class Status {

	private final String NAME;

	public static final Status FREE = new Status("FREE");
	public static final Status BUSY = new Status("BUSY");
	public static final Status VOCATION = new Status("VOCATION");

	private Status(String name) {
		this.NAME = name;
	}

	public String getNAME() {
		return NAME;
	}

	@Override
	public String toString() {

//			return getNAME();
		return NAME;
	}

}
