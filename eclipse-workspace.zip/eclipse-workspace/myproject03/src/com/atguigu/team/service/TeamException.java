package com.atguigu.team.service;
/**
 * 自定义异常类
 * @Description
 * @author zyp   Email:1521165790@qq.com
 * @version
 * @data 2023年1月22日下午11:28:02
 */
public class TeamException extends Exception {
	  static final long serialVersionUID = -3387516994124229948L;
	  
	  public TeamException() {}
	  
	  public TeamException(String msg) {
		  super(msg);
	  }
	  
	  
}
