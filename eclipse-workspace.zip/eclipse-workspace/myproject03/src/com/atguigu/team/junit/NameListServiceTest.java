package com.atguigu.team.junit;

import org.junit.Test;

import com.atguigu.team.domain.Employee;
import com.atguigu.team.service.NameListService;
import com.atguigu.team.service.TeamException;

/**
 * 对于NameListService类的测试
 * @Description
 * @author zyp   Email:1521165790@qq.com
 * @version
 * @data 2023年1月22日下午11:33:18
 */
public class NameListServiceTest {
	@Test
	public void testGetAllEmployees() {
		NameListService service = new NameListService();
		Employee[] employees = service.getAllEmployees();
		for (int i = 0; i < employees.length; i++) {
			System.out.println(employees[i]);
		}
	}
	@Test
	public void TestGetEmployee() {
		NameListService service = new NameListService();
		int id=101;
		try {
			Employee employee = service.getEmployee(id);
			System.out.println(employee);
		} catch (TeamException e) {
			
//			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

}
