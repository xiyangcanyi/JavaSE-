package com.atguigu.java;
/*
 * Error:
 * Java 虚拟机无法解决的严重问题。如：JVM系统个内部错误、资源耗尽等严重情况。比如：StackOVerflowError错误
 * 
 * 一般不编写针对性代码进行处理
 * 
 * 
 * 
 * 
 * 
 * 
 */
public class ErrorTest {
	public static void main(String[] args) {
//		栈溢出：java.lang.StackOverflowError
//		main(args);
//		堆溢出：java.lang.OutOfMemoryError:
//		Integer[] arr= new Integer[1024*1024*1024];
				
	}

}
