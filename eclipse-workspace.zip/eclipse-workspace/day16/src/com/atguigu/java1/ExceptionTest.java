package com.atguigu.java1;

import java.io.File;
import java.io.FileInputStream;
import java.util.Date;
import java.util.Scanner;

import org.junit.Test;

/*
 * 一、异常的体系结构i
 * java.lang.Throwable
 * 		|----java.lang.Error:一般不进行针对性的代码进行处理。
 * 		|----java.lang.Exception:可以进行异常的处理
 * 			|----编译时异常（checked）、
 * 					|-----IOException
 * 						|----FileNotFoundException
 * 						|---ClassNotFoundException
 * 			|----运行时异常（unchecked，RuntimeException）
 * 				|-----NullPointerException
 * 				|-----ArrayIndexOutOfBoundsException
 * 				|-----ClassCastException
 * 				|-----NumberFormatException
 * 				|-----InputMismatchException
 * 				|-----ArithemeticException
 * 	
 * 
 * 面试题：常见的异常有哪些？举例说明
 * 
 * 
 * 
 * 
 */

public class ExceptionTest {
//	***********************以下是运行时异常****************************
//	NullPointerException
	@Test
	public void test1() {
//		int[] arr=null;
//		System.out.println(arr[3]);
//		String str="abc";
//		str=null;
//		System.out.println(str.charAt(0));
	}
//	ArrayIndexOutOfBoundsException
	@Test
	public void test2() {
//		java.lang.ArrayIndexOutOfBoundsException: Index 10 out of bounds for length 10
//		int[] arr=new int[10];
//		System.out.println(arr[10]);
//		java.lang.StringIndexOutOfBoundsException: String index out of range: 3
		String str="abc";
//		str=null;
		System.out.println(str.charAt(3));
	}
//	ClassCastException 类型转换异常
	@Test
	public void test3() {
		Object o=new Date();
		String str=(String)o;
	}
//	NumberFormatException 
	@Test
	public void test4() {
//		java.lang.NumberFormatException: For input string: "abc"
	

//		String str = "123";
		String str = "abc";
		
		int num = Integer.parseInt(str);
	}
//	InputMismatchException
	@Test
	public void test5() {
//		java.util.InputMismatchException   输入字符串报错

		Scanner scanner = new Scanner(System.in);
		int num = scanner.nextInt();
		System.out.println(num);
		scanner.close();
    
	}
//	ArithemeticException 比如：除数为0
	@Test
	public void test6() {
		int a=10;
		int b=2;
		System.out.println(a/b);
	}

	
//	***********************以下是编译时异常****************************
//	FileNotFoundException
	@Test
	public void test7() {
//		File file=new File("Hello.txt");
//		FileInputStream fis = new FileInputStream(file);
//		int data = fis.read();
//		while(data != -1) {
//			System.out.println((char)data);
//			 data = fis.read();
//		}
//		fis.close();
	}
	
	
	
	
	

	
	
	
	
	

}
