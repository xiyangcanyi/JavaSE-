package com.atguigu.java1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.Test;

/*
 * 异常的处理：抓抛模型
 * 过程一：“抛”：程序在正常执行的过程中，一旦出现异常，就会在异常代码处生成一个对应异常类的对象
 * 			并将此对象抛出。
 * 			一旦抛出对象以后，其后的代码就不再执行。
 * 
 * 		关于异常对象的产生： ①：系统自动生成的异常对象
 * 						② 手动的生成一个异常对象，并抛出（throw）
 * 
 * 
 * 过程二：“抓”：可以理解为异常处理方式：①try-catch-finally  ②throws
 * 
 * 二、try-catch-finally的使用
 * 
 * try{
 *   //可能出现异常的代码
 *   
 * }catch(异常类型1 变量名1){
 * 		//处理异常的方式1
 * }catch(异常类型2 变量名2){
 * 		//处理异常的方式2
 * }catch(异常类型3 变量名3){
 * 		//处理异常的方式3
 * }
 * ...
 * finally{
 * 		//一定会执行的代码
 * 
 * }
 * 说明：
 * 1.finally是可选的。
 * 2.使用try将可能出现的异常代码包装起来，在执行过程中，一旦出现异常，就会生成一个对应异常类的对象，根据此对象
 * 	的类型，去catch中进行匹配
 * 3.一旦try中的匹配对象匹配到某一个catch时，就会进入catch中进行异常的处理。一旦处理完成之后，就跳出当前的try
 * -catch结构了（在没有finally的情况）。继续执行其后的代码
 * 4.catch中的异常类型如果没有子父类关系，则谁声明在上，谁声明在下无所谓。
 * 	catch中的异常类型如果满足子父类关系，则要求子类一定声明在父类的上面，否则报错。
 * 
 * 5.常用的异常对象处理的方式：①String getMessage（）  ② printStackTrack（）
 * 6.在try结构中声明的变量，在出了try结构以后，就不能再被调用
 * 7.try-catch-finally结构可以嵌套
 * 
 * 如何看待代码中的编译时异常和运行时异常？
 * 体会1：使用try-catch-finally处理编译时异常，使得程序在编译时就不再报错，但是运行时仍可能报错。
 * 		相当于我们使用try-catch-finally将一个编译时可能出现的异常，延迟到运行时出现。
 * 
 * 体会2：开发中，由于运行时异常比较常见，所以我们通常不针对运行时异常编写try-catch-finally
 * 		针对于编译时异常，我们一定考虑异常处理
 * 
 * 2.3面试题：
 * final、finally、finalize三者区别？
 * 
 * 类似：
 * throw与throws的区别？
 * 
 * throw 表示抛出一个异常类的对象，生成异常类对象的过程。声明在方法体内。
 * throws 属于异常处理的一种方式，声明在方法的声明处。
 * 
 * 
 * 
 * Collection与Collections？
 * String、StringBuffer、StringBuilder？
 * ArrayList、LinkedList？
 * HashMap、LinkedHashMap？
 * 重写、重载
 * 
 * 
 * 结构不相似的：
 * 抽象类、接口？
 * ==、equals()
 * sleep()，wait()
 * 
 * 
 * 
 * 
 * 
 */
public class ExceptionTest1 {
	@Test
	public void test1() {
		String str = "123";
		str="abc";
		int num=0;
		try {
			num = Integer.parseInt(str);
			System.out.println("hello---1");
		} catch (NumberFormatException e) {
			System.out.println("出现数值转换异常了，不要着急...");
//			String getMessage();
//			System.out.println(e.getMessage());
//			printStackTrace();
			e.printStackTrace();
		}catch (NullPointerException e) {
			System.out.println("出现空指针异常了，不要着急...");
		}
		System.out.println("hello---2");
		System.out.println(num);
	}
	
	@Test
	public void test2() {
		try {
			File file=new File("Hello.txt");
			FileInputStream fis = new FileInputStream(file);
			int data = fis.read();
			while(data != -1) {
				System.out.println((char)data);
				 data = fis.read();
			}
			fis.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
	

}
