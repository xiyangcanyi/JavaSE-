package com.atguigu.java;

public class Creature {
	public void breath() {
		System.out.println("呼吸");
	}

}
